# -*- coding: utf-8 -*-
"""最终交付：11条 + ⑫⑬⑭ 三条打新底仓约束，输出 CSV + HTML"""
import duckdb, pandas as pd, numpy as np, json
pd.set_option('display.width',330); pd.set_option('display.max_columns',80)
BASE='2026-10-15'; ANN=np.sqrt(252)
con=duckdb.connect(':memory:')
con.execute("ATTACH 'D:/repository/数据湖/data/cnequity/duckdb/cnequity.duckdb' AS src (read_only)")

pool=pd.read_csv('高股息筛选结果_行业豁免版.csv',encoding='utf-8-sig')
mine=pd.read_csv('最终核心池_银行核验后.csv',encoding='utf-8-sig')[['symbol','结论']]
pool=pool.merge(mine,on='symbol',how='left'); pool['结论']=pool['结论'].fillna('前置剔除')
pool['板块']=np.where(pool.symbol.str.startswith('6'),'沪市','深市')
syms=pool.symbol.tolist(); q=",".join("'"+s+"'" for s in syms)

px=con.execute(f"select symbol,trade_date,close from src.daily_bars where symbol in ({q}) and trade_date<=DATE '{BASE}' and close>0 order by 1,2").df()
ca=con.execute(f"""select symbol,cast(ex_date as date) ex_date,coalesce(cash_dividend,0) cash,
 coalesce(bonus_ratio,0) bonus,coalesce(transfer_ratio,0) transfer from src.corporate_actions
 where symbol in ({q}) and cast(ex_date as date)<=DATE '{BASE}'""").df()
rec=[]
for s,g in px.groupby('symbol'):
    g=g.sort_values('trade_date').reset_index(drop=True)
    g['c_prev']=g['close'].shift(1)
    c=ca[ca.symbol==s]
    g=g.merge(c[['ex_date','cash','bonus','transfer']],left_on='trade_date',right_on='ex_date',how='left')
    prev=(g['c_prev']-g['cash'].fillna(0))/(1+g['bonus'].fillna(0)+g['transfer'].fillna(0))
    g['r']=np.where(g['ex_date'].notna(),g['close']/prev-1,g['close']/g['c_prev']-1)
    rec.append(g[['symbol','trade_date','r']])
allr=pd.concat(rec,ignore_index=True)
vr=[]
for s,g in allr.groupby('symbol'):
    r=g['r'].dropna().tail(252)
    P=(1+r).cumprod()
    vr.append({'symbol':s,'vol':round(float(np.std(r,ddof=1))*ANN*100,2),
               'vol_h1':round(float(np.std(r.tail(126),ddof=1))*ANN*100,2),
               'mdd':round(float((P/P.cummax()-1).min())*100,2)})
vol=pd.DataFrame(vr)
amt=con.execute(f"""with d as (select symbol,amount,row_number() over(partition by symbol order by trade_date desc) rk
 from src.daily_bars where symbol in ({q}) and trade_date<=DATE '{BASE}' and amount is not null)
 select symbol,avg(amount)/1e4 amt_wan, min(amount)/1e4 amt_min from d where rk<=63 group by 1""").df()

d=pool.merge(vol,on='symbol').merge(amt,on='symbol')
d['yld_stab']=(d['d25']/d['px']*100).round(2)
d['r_stab']=(d['yld_stab']/d['yld3']).round(2)
d['c12']=d['vol']<25; d['c13']=d['amt_wan']>=5000; d['c14']=d['r_stab']<2
d['core']=d['结论'].isin(['保留','降级'])
d['sel']=d['core']&d['c12']&d['c13']&d['c14']
d=d.sort_values(['sel','vol'],ascending=[False,True])

cols=['symbol','name','板块','industry_name','结论','vol','vol_h1','mdd','amt_wan','yld_stab','yld3','r_stab','c12','c13','c14','sel']
d[cols].to_csv('打新底仓_最终名单.csv',index=False,encoding='utf-8-sig')

p=d[d.sel]
print(f"=== 11条 + ⑫⑬⑭ 最终通过：{len(p)} 只 ===")
print(p[['symbol','name','板块','vol','mdd','amt_wan','yld_stab','industry_name']].round(2).to_string(index=False))
print(f"\n板块分布: 沪 {(p.板块=='沪市').sum()} / 深 {(p.板块=='深市').sum()}")

# ---------- 生成 HTML ----------
EMO={'银行Ⅱ':'🏦','国有大型银行Ⅲ':'🏦','交通运输':'🚢','环保':'💧','中药Ⅲ':'💊','复合肥':'🌾',
     '火力发电':'⚡','电能综合服务':'⚡','公用事业':'⚡','航运':'🚢','煤炭':'⛏️','家用电器':'🏠',
     '彩电':'📺','油服工程':'🛢️','汽车':'🚗','纺织服饰':'👗','机械设备':'⚙️'}
def tag(v,ok,unit=''):
    c='ok' if ok else 'no'; s='✓' if ok else '✗'
    return f'<span class="{c}">{v}{unit} {s}</span>'

rows=[]
for _,r in d.iterrows():
    cls='hit' if r['sel'] else ('dim' if r['core'] else 'out')
    badge='<span class="bd hit">入选</span>' if r['sel'] else ('<span class="bd no">不达标</span>' if r['core'] else '<span class="bd gray">前置剔除</span>')
    rows.append(f"""<tr class="{cls}">
<td class="nm"><b>{r['name']}</b><small>{r['symbol']} · {r['板块']}</small></td>
<td>{EMO.get(r['industry_name'],'')} {r['industry_name']}</td>
<td class="num">{tag(f"{r['vol']:.2f}",r['c12'],'%')}<small>近半年 {r['vol_h1']:.1f}%</small></td>
<td class="num neg">{r['mdd']:.2f}%</td>
<td class="num">{tag(f"{r['amt_wan']:,.0f}",r['c13'],'万')}</td>
<td class="num">{tag(f"{r['yld_stab']:.2f}",r['c14'],'%')}<small>均值 {r['yld3']:.2f}% · {r['r_stab']:.2f}×</small></td>
<td class="ctr">{badge}</td></tr>""")

sens=[]
for th in [22,25,28,30,32]:
    sub=d[(d['vol']<th)&d.c13&d.c14&d.core].sort_values('vol')
    szn=int((sub.板块=='深市').sum())
    sens.append((f'< {th}%', len(sub), f'深市 {szn}', '、'.join(sub.name) if len(sub) else '—'))
html=f"""<!DOCTYPE html>
<html lang="zh-CN"><head><meta charset="utf-8"><title>打新底仓 · 低波与流动性筛选</title>
<style>
:root{{--bg:#0f1115;--card:#171a21;--card2:#1d2129;--line:#2a2f3a;--tx:#e6e8ec;--tx2:#9aa3b2;--tx3:#6b7381;
--red:#f0554d;--green:#2fb87a;--amber:#e8a33d;--blue:#4a90d9;--purple:#9b6dd6;}}
*{{box-sizing:border-box;margin:0;padding:0}}
body{{background:var(--bg);color:var(--tx);font:14px/1.6 -apple-system,"Segoe UI","PingFang SC","Microsoft YaHei",sans-serif;padding:32px 28px 60px}}
.wrap{{max-width:1180px;margin:0 auto}}
h1{{font-size:24px;font-weight:650;letter-spacing:-.3px;margin-bottom:6px}}
.sub{{color:var(--tx2);font-size:13px;margin-bottom:26px}}
.sub b{{color:var(--tx)}}
.kpi{{display:grid;grid-template-columns:repeat(5,1fr);gap:12px;margin-bottom:26px}}
.k{{background:var(--card);border:1px solid var(--line);border-radius:10px;padding:14px 16px}}
.k .lab{{color:var(--tx3);font-size:11.5px;letter-spacing:.4px;margin-bottom:5px}}
.k .val{{font-size:22px;font-weight:650;font-variant-numeric:tabular-nums}}
.k .val small{{font-size:12px;font-weight:400;color:var(--tx2);margin-left:3px}}
.k.hi{{border-color:#2f5d46;background:linear-gradient(180deg,#17251e,#171a21)}}
.k.hi .val{{color:var(--green)}}
h2{{font-size:15px;font-weight:600;margin:28px 0 12px;padding-left:10px;border-left:3px solid var(--blue)}}
table{{width:100%;border-collapse:separate;border-spacing:0;background:var(--card);border:1px solid var(--line);border-radius:10px;overflow:hidden;font-size:13px}}
th{{background:var(--card2);color:var(--tx2);font-weight:500;font-size:11.5px;letter-spacing:.3px;text-align:left;padding:10px 12px;border-bottom:1px solid var(--line);white-space:nowrap}}
td{{padding:10px 12px;border-bottom:1px solid #21252e;vertical-align:middle}}
tr:last-child td{{border-bottom:none}}
tr.hit{{background:rgba(47,184,122,.055)}}
tr.hit:hover{{background:rgba(47,184,122,.1)}}
tr.dim{{opacity:.62}} tr.dim:hover{{opacity:.85;background:#1a1e25}}
tr.out{{opacity:.34}} tr.out:hover{{opacity:.5}}
.num{{text-align:right;font-variant-numeric:tabular-nums;white-space:nowrap}}
.ctr{{text-align:center}}
.nm b{{font-weight:600;font-size:13.5px}}
.nm small,.num small{{display:block;color:var(--tx3);font-size:10.5px;line-height:1.35;margin-top:1px}}
.ok{{color:var(--green)}} .no{{color:var(--amber)}} .neg{{color:var(--green)}}
.bd{{display:inline-block;padding:2px 9px;border-radius:20px;font-size:11px;font-weight:500;white-space:nowrap}}
.bd.hit{{background:rgba(47,184,122,.16);color:var(--green);border:1px solid rgba(47,184,122,.35)}}
.bd.no{{background:rgba(232,163,61,.13);color:var(--amber);border:1px solid rgba(232,163,61,.3)}}
.bd.gray{{background:#22262f;color:var(--tx3);border:1px solid var(--line)}}
.note{{background:var(--card);border:1px solid var(--line);border-left:3px solid var(--amber);border-radius:8px;padding:14px 18px;margin-top:18px;font-size:12.5px;color:var(--tx2)}}
.note b{{color:var(--tx)}} .note.warn{{border-left-color:var(--red)}}
.note.info{{border-left-color:var(--blue)}}
.sens{{display:grid;grid-template-columns:repeat(5,1fr);gap:10px;margin-top:6px}}
.s{{background:var(--card2);border:1px solid var(--line);border-radius:8px;padding:11px 12px}}
.s .t{{color:var(--tx3);font-size:11px;margin-bottom:4px}}
.s .n{{font-size:19px;font-weight:650;font-variant-numeric:tabular-nums}}
.s .l{{color:var(--tx2);font-size:10.5px;margin-top:5px;line-height:1.4;height:44px;overflow:hidden}}
.s.on{{border-color:#3a6b53;background:#18241d}} .s.on .n{{color:var(--green)}}
.foot{{color:var(--tx3);font-size:11.5px;margin-top:32px;padding-top:16px;border-top:1px solid var(--line);line-height:1.8}}
</style></head><body><div class="wrap">
<h1>打新底仓 · 低波与流动性叠加筛选</h1>
<div class="sub">11 条高股息 <b>+</b> ⑫年化波动率 <b>+</b> ⑬日均成交额 <b>+</b> ⑭股息率异常 · 基准日 <b>{BASE}</b> · 前复权重建（数据湖 qfq 未生效已修正）</div>

<div class="kpi">
<div class="k hi"><div class="lab">最终入选</div><div class="val">{len(p)}<small>只</small></div></div>
<div class="k"><div class="lab">沪市 / 深市</div><div class="val">{(p.板块=='沪市').sum()} <small>/</small> {(p.板块=='深市').sum()}</div></div>
<div class="k"><div class="lab">最低年化波动</div><div class="val">{p.vol.min():.1f}<small>%</small></div></div>
<div class="k"><div class="lab">平均股息率</div><div class="val">{p.yld_stab.mean():.2f}<small>%</small></div></div>
<div class="k"><div class="lab">平均日均成交</div><div class="val">{p.amt_wan.mean()/10000:.1f}<small>亿</small></div></div>
</div>

<h2>名单（按年化波动率升序）</h2>
<table><thead><tr>
<th>标的</th><th>行业</th><th class="num">⑫ 年化波动率 &lt;25%</th><th class="num">近1年最大回撤</th>
<th class="num">⑬ 日均成交额 ≥5000万</th><th class="num">⑭ 股息率 &lt;均值×2</th><th class="ctr">判定</th>
</tr></thead><tbody>{''.join(rows)}</tbody></table>

<h2>阈值敏感性（累计口径，⑬⑭ 已达标）</h2>
<div class="sens">{''.join(f'<div class="s{" on" if lab=="< 25%" else ""}"><div class="t">年化波动 {lab}</div><div class="n">{n} <span style="font-size:11px;font-weight:400;color:var(--tx3)">只 · {sz}</span></div><div class="l">{l}</div></div>' for lab,n,sz,l in sens)}</div>

<div class="note warn"><b>⚠ 深市市值缺口</b>：25% 阈值下入选 {len(p)} 只中，深市 <b>{(p.板块=='深市').sum()}</b> 只。打新需沪深两市分别持有市值，深市为空意味着无法申购深市新股（深主板 + 创业板）。深市原池最低波动标的为陕西能源 <b>30.24%</b>，需放宽至 31% 才能纳入。</div>

<div class="note info"><b>口径说明</b>：数据湖 <code>daily_bars_adj.qfq_close</code> 与 <code>close</code> 完全相等，前复权实际未生效。本表已用 <code>corporate_actions</code> 的现金分红/送转比例重建复权收益率，公式 r<sub>T</sub>=close<sub>T</sub>/[(close<sub>T-1</sub>-每股现金红利)/(1+送股+转增)]-1。修正后波动率较原口径低 0.0–1.0pct，排名不变。10-16 日成交额数据不完整（仅为常态 45%），基准日取 10-15。</div>

<div class="note"><b>⑭ 口径选择</b>：主口径采用「最近完整年度分红/现价」（稳态），避免滚动 12 个月实施金额被中期分红节奏干扰。若改用 TTM 实施口径，仅芭田股份由 1.78× 升至 2.27× 触发剔除，但它已被 ⑫（37.21%）拦下，最终名单不受影响。</div>

<div class="foot">
数据源：cnequity 数据湖 · 财务由 financial_statement_items / 分红由东财 RPT_SHAREBONUS_DET / 除权由 corporate_actions<br>
波动率为 252 个交易日日收益率样本标准差 × √252；成交额为 63 个交易日算术均值。仅供研究，不构成投资建议。
</div>
</div></body></html>"""
open('打新底仓_低波筛选.html','w',encoding='utf-8').write(html)
print("\n已生成 打新底仓_低波筛选.html")
