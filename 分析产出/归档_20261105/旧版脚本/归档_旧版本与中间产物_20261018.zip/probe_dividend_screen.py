import duckdb
con = duckdb.connect('D:/repository/数据湖/data/cnequity/duckdb/cnequity.duckdb', read_only=True)
q = lambda s: con.sql(s).df()

# 股票池：2022-01-01 前上市的A股
base = q("""
select symbol, name, list_date from instruments
where asset_type='stock' and list_date <= DATE '2022-01-01'
  and (delist_date is null or delist_date > DATE '2026-10-01')
""")
print('universe(2022前上市且未退市):', len(base))

# 年度每股现金分红（按除权日年份汇总）
dps = q("""
select symbol, year(ex_date) y, sum(cash_dividend) dps, count(*) n
from corporate_actions
where action_type='cash_dividend' and ex_date between DATE '2023-01-01' and DATE '2025-12-31'
group by 1,2
""")
piv = dps.pivot(index='symbol', columns='y', values='dps').reset_index()
piv.columns = ['symbol','dps2023','dps2024','dps2025']
con.register('dps_piv', piv)

# 年末收盘价（各年最后一个交易日）
yc = q("""
with lastd as (
  select year(trade_date) y, max(trade_date) d from daily_bars
  where trade_date between DATE '2023-01-01' and DATE '2025-12-31' group by 1)
select b.symbol, lastd.y, b.close
from daily_bars b join lastd on b.trade_date=lastd.d
""")
ypiv = yc.pivot(index='symbol', columns='y', values='close').reset_index()
ypiv.columns = ['symbol','c2023','c2024','c2025']
con.register('yclose', ypiv)

# 12个月涨跌幅（前复权）
ret = q("""
with p as (
 select symbol,
   max(case when trade_date=DATE '2025-10-09' then qfq_close end) p0,
   max(case when trade_date=DATE '2026-10-09' then qfq_close end) p1
 from daily_bars_adj where trade_date in (DATE '2025-10-09', DATE '2026-10-09') group by 1)
select symbol,
       (p1/p0-1)*100 ret12m
from p where p0 is not null and p1 is not null
""")
con.register('ret12m', ret)

f = q("""
with j as (
  select b.symbol, b.name,
         d.dps2023, d.dps2024, d.dps2025,
         y.c2023, y.c2024, y.c2025, r.ret12m
  from base b
  left join dps_piv d using(symbol)
  left join yclose y using(symbol)
  left join ret12m r using(symbol)
), s as (
  select *, 
    case when dps2023>0 and dps2024>0 and dps2025>0 then 1 else 0 end pass1,
    ( coalesce(dps2023/c2023,0)+coalesce(dps2024/c2024,0)+coalesce(dps2025/c2025,0) )/3*100 yld3,
    ret12m
  from j
)
select
  count(*) n0,
  sum(pass1) n1,
  sum(case when pass1=1 and yld3>3.5 then 1 else 0 end) n2,
  sum(case when pass1=1 and yld3>3.5 and ret12m>-20 then 1 else 0 end) n9
from s
""")
print(f.to_string())
q("""
select symbol,name, round(yld3,2) 三年均股息率, round(dps2023,3) d23, round(dps2024,3) d24, round(dps2025,3) d25,
       round(ret12m,1) 涨跌幅
from (select b.symbol,b.name,d.dps2023,d.dps2024,d.dps2025,y.c2023,y.c2024,y.c2025,r.ret12m,
      (coalesce(d.dps2023/y.c2023,0)+coalesce(d.dps2024/y.c2024,0)+coalesce(d.dps2025/y.c2025,0))/3*100 yld3
      from base b left join dps_piv d using(symbol) left join yclose y using(symbol) left join ret12m r using(symbol))
where dps2023>0 and dps2024>0 and dps2025>0 and yld3>3.5 and ret12m>-20
order by yld3 desc
""").to_csv('D:/repository/数据湖/_probe_pass129.csv', index=False)
print('saved probe csv')
