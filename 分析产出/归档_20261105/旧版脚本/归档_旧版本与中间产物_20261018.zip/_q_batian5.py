import duckdb, pandas as pd
pd.set_option('display.width',250)
con = duckdb.connect(':memory:')
con.execute("ATTACH 'D:/repository/数据湖/data/cnequity/duckdb/cnequity.duckdb' AS src (read_only)")
print("=== 最新价 / 区间涨跌 ===")
print(con.execute("""
select max(trade_date) 最新日期,
       arg_max(close, trade_date) 最新收盘
from src.daily_bars where symbol='002170.SZ'""").df().to_string(index=False))
print(con.execute("""
select trade_date, close, qfq_close from src.daily_bars_adj
where symbol='002170.SZ' and trade_date in (DATE '2025-10-09', DATE '2026-10-09')
order by trade_date""").df().to_string(index=False))
print("\n=== 近3年年末前复权价 & 股息率 ===")
print(con.execute("""
select year(trade_date) y, arg_max(qfq_close, trade_date) qfq_ye
from src.daily_bars_adj where symbol='002170.SZ' group by 1 order by 1""").df().to_string(index=False))
