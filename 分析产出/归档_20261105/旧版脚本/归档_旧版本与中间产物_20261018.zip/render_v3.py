"""生成行业豁免版报表：④ 银行豁免、⑤ 公用事业豁免。"""
import pandas as pd, html

d = pd.read_csv('D:/repository/数据湖/分析产出/高股息筛选结果_行业豁免版.csv')
d = d.sort_values('yld_ttm', ascending=False)
for y in ('23', '24', '25'):
    d['cd' + y] = d['ocfp' + y] / d['d' + y]
    d['cn' + y] = d['cf' + y] / d['np' + y] * 100
    d['p' + y] = d['d' + y] / d['eps' + y] * 100

def cell(avg, ys, fmt, badge=''):
    small = ' / '.join(fmt.format(x) if pd.notna(x) else '—' for x in ys)
    return f'<div class="avg">{fmt.format(avg)}{badge}</div><div class="yr">{small}</div>'

body = []
for _, r in d.iterrows():
    up = r.ret12m >= 0
    bank = r.is_bank == 1
    util = r.is_util == 1
    b4 = '<span class="ex">豁免</span>' if bank else ''
    b5 = '<span class="ex">豁免</span>' if util else ''
    dcell = f'<div class="avg {"dim" if bank else ""}">{r.debt:.1f}%{b4}</div>'
    body.append(f"""<tr>
<td class="code">{r.symbol}</td><td class="name">{html.escape(str(r['name']))}</td>
<td class="ind">{html.escape(str(r.industry_name if pd.notna(r.industry_name) else '—'))}</td>
<td class="num hi">{r.yld_ttm:.2f}%</td><td class="num">{r.yld3:.2f}%</td>
<td class="num">{cell(r.roe3, [r.roe23, r.roe24, r.roe25], '{:.2f}')}</td>
<td class="num">{cell(r.payout3, [r.p23, r.p24, r.p25], '{:.1f}', b5)}</td>
<td class="num">{cell(r.cfdiv3, [r.cd23, r.cd24, r.cd25], '{:.2f}')}</td>
<td class="num">{cell(r.cfnp3, [r.cn23, r.cn24, r.cn25], '{:.0f}')}</td>
<td class="num">{dcell}</td>
<td class="num">{r.cagr3:+.1f}%</td><td class="num">{r.amt3:.1f}</td>
<td class="num {'up' if up else 'down'}">{r.ret12m:+.1f}%</td></tr>""")

funnel = [('① 连续 3 年分红（报告期口径）', 2701), ('② 3 年均股息率 > 3.5%', 341),
          ('③ 归母净利 3 年均正增长', 82), ('④ 资产负债率 < 60%（银行豁免）', 68),
          ('⑤ 支付率 30–80%（公用事业豁免）', 45), ('⑥ 现金流/分红 > 1', 42),
          ('⑦ 3 年均 ROE > 8%', 38), ('⑧ 现金流/净利 > 80%', 37),
          ('⑨ 近 12 月涨跌 > −20%', 35), ('⑩ 净利 CAGR > 3%', 30),
          ('⑪ 累计分红 > 10 亿', 23)]
fhtml = ''.join(f'<li><span>{n}</span><b>{c}</b></li>' for n, c in funnel)

nb = int((d.is_bank == 1).sum()); nu = int((d.is_util == 1).sum())
doc = f"""<!DOCTYPE html><html lang="zh-CN"><head><meta charset="utf-8">
<title>高股息 11 条件筛选（行业豁免版）</title>
<style>
*{{box-sizing:border-box}}
body{{margin:0;padding:32px 28px 48px;background:#0d1117;color:#e6edf3;
 font-family:-apple-system,"Segoe UI","Microsoft YaHei",sans-serif}}
h1{{font-size:22px;margin:0 0 6px;font-weight:600}}
.meta{{color:#8b949e;font-size:12.5px;line-height:1.8;margin-bottom:20px}}
.meta b{{color:#c9d1d9}}
.funnel{{display:flex;flex-wrap:wrap;gap:6px;list-style:none;padding:0;margin:0 0 24px}}
.funnel li{{background:#161b22;border:1px solid #21262d;border-radius:6px;padding:7px 11px;
 font-size:11.5px;color:#8b949e;display:flex;gap:8px;align-items:center}}
.funnel li b{{color:#58a6ff;font-size:14px;font-weight:600;font-variant-numeric:tabular-nums}}
table{{width:100%;border-collapse:collapse;font-size:12.5px;font-variant-numeric:tabular-nums}}
thead th{{text-align:right;padding:8px 6px;border-bottom:1px solid #30363d;color:#8b949e;
 font-size:11px;font-weight:500;line-height:1.5;white-space:nowrap;vertical-align:bottom}}
thead th:nth-child(-n+3){{text-align:left}}
.sub{{color:#484f58;font-size:10px;display:block}}
tbody td{{padding:10px 6px;border-bottom:1px solid #161b22;text-align:right;white-space:nowrap}}
tbody td.code{{text-align:left;color:#8b949e;font-size:12px}}
tbody td.name{{text-align:left;font-weight:600;font-size:13px}}
tbody td.ind{{text-align:left;color:#6e7681;font-size:11px}}
tbody tr:hover{{background:#11161d}}
.avg{{font-weight:700;font-size:13px}}
.yr{{color:#6e7681;font-size:10.5px;margin-top:2px}}
.hi{{color:#f0883e;font-weight:700;font-size:14px}}
.dim{{color:#6e7681}}
.up{{color:#f85149;font-weight:600}}
.down{{color:#3fb950;font-weight:600}}
.ex{{display:inline-block;margin-left:4px;font-size:9px;padding:1px 4px;border-radius:3px;
 background:#2a2135;color:#bc8cff;font-weight:500;vertical-align:middle}}
.note{{margin-top:24px;font-size:11.5px;color:#6e7681;line-height:1.9;max-width:1180px}}
.note b{{color:#8b949e}}
code{{background:#161b22;padding:1px 5px;border-radius:4px;font-size:11px;color:#79c0ff}}
</style></head><body>
<h1>高股息 11 条件筛选 · 行业豁免版</h1>
<div class="meta">命中 <b>{len(d)}</b> 只（银行 {nb}、公用事业 {nu}）　·　按<b>当前股息率（TTM）</b>降序　·　价格区间 2025-10-09 → 2026-10-09（前复权）　·　负债率基准 2026 中报<br>
豁免规则：<b>④ 资产负债率 &lt; 60%</b> → 银行类不适用　·　<b>⑤ 股息支付率 30–80%</b> → 公用事业类不适用</div>
<ul class="funnel">{fhtml}</ul>
<table><thead><tr>
<th>代码</th><th>名称</th><th>行业</th><th>当前股息率<span class="sub">TTM</span></th><th>3年均股息率</th>
<th>ROE<span class="sub">加权 %</span></th><th>股息支付率<span class="sub">%</span></th>
<th>现金流/分红<span class="sub">倍</span></th><th>现金流/净利<span class="sub">%</span></th>
<th>资产负债率<span class="sub">2026H1</span></th><th>净利CAGR<span class="sub">22→25</span></th>
<th>累计分红<span class="sub">亿元</span></th><th>近12月涨跌</th>
</tr></thead><tbody>{''.join(body)}</tbody></table>
<div class="note">
<b>豁免口径</b>：行业取湖内 <code>industry_members</code>（eastmoney 分类）。银行 = 名称含「银行」或用 475 / 1611 节点；
公用事业 = 公用事业、电力、火力发电、水力发电、其他能源发电、电能综合服务、水务、燃气、热力。<br>
<b>豁免带来的变化</b>：④ 通过数 41 → 68，新增 6 家银行进入终选（负债率 91.7%–93.5%，属行业常态）；
⑤ 通过数 31 → 45，但入选的 4 只公用事业（申能、佛燃、陕西能源、福能）支付率本就落在 30–80%，<b>对最终名单无影响</b>，
豁免只是让 14 只高派现公用事业继续进入后续环节。<br>
<b>提示</b>：银行 ⑥⑧ 的「经营现金流」含同业往来与拆借波动，江苏银行 ⑧ 达 828%，指标偏高属科目特性，横向比较意义有限。
</div></body></html>"""
open('D:/repository/数据湖/分析产出/高股息筛选结果_行业豁免版.html', 'w', encoding='utf-8').write(doc)
print('ok')
