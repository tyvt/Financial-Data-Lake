import duckdb, pandas as pd
pd.set_option('display.width',250)
con = duckdb.connect(':memory:')
con.execute("ATTACH 'D:/repository/数据湖/data/cnequity/duckdb/cnequity.duckdb' AS src (read_only)")
print("=== 2026Q2 / 2025Q2 披露日期 ===")
print(con.execute("""
select report_period, min(announce_date) ann, max(announce_date) ann2, count(*) n
from src.financial_statement_items where symbol='002170.SZ' and report_period in ('2026Q2','2025Q2')
group by 1 order by 1""").df().to_string(index=False))

print("\n=== 分红明细（按报告期）===")
print(con.execute("""
select cast(report_date as date) report_date, per10, total_shares/1e8 sh_yi,
       round(per10/10.0*total_shares/1e8,4) amt_yi,
       cast(ex_date as date) ex_date, progress
from read_parquet('dividend_by_report.parquet')
where symbol='002170.SZ' order by 1""").df().to_string(index=False))

print("\n=== 股息率（TTM）与近3年 ===")
print(con.execute("""
with d as (select cast(report_date as date) rd, per10, total_shares,
                  per10/10.0*total_shares/1e8 amt
           from read_parquet('dividend_by_report.parquet')
           where symbol='002170.SZ' and progress='实施分配' and per10>0)
select year(rd) y, round(sum(per10),2) per10_sum, round(sum(amt),3) amt_yi
from d where rd between DATE '2022-01-01' and DATE '2026-12-31' group by 1 order by 1""").df().to_string(index=False))

print("\n=== 当前估值/股息率 ===")
print(con.execute("""
select symbol, trade_date, close, pe_ttm, pb, dividend_yield from src.valuation_metrics
where symbol='002170.SZ' order by trade_date desc limit 5""").df().to_string(index=False) if True else '')
