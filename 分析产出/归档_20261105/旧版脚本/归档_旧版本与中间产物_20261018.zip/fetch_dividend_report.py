"""按报告期抓取东财分红送配明细（RPT_SHAREBONUS_DET），供 ②⑤⑪ 按会计年度归因。"""
import json, time, random, urllib.request, urllib.parse
from concurrent.futures import ThreadPoolExecutor, as_completed
import duckdb, pandas as pd

DB = 'D:/repository/数据湖/data/cnequity/duckdb/cnequity.duckdb'
con = duckdb.connect(DB, read_only=True)
syms = [r[0] for r in con.sql("""
select symbol from corporate_actions
where action_type='cash_dividend' and cash_dividend>0
  and ex_date between DATE '2023-01-01' and DATE '2025-12-31'
group by 1
having sum(case when year(ex_date)=2023 then 1 else 0 end)>0
   and sum(case when year(ex_date)=2024 then 1 else 0 end)>0
   and sum(case when year(ex_date)=2025 then 1 else 0 end)>0
""").fetchall()]
print('symbols', len(syms))

UA = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)', 'Referer': 'https://data.eastmoney.com/'}
BASE = 'https://datacenter-web.eastmoney.com/api/data/v1/get'
COLS = 'SECUCODE,REPORT_DATE,PRETAX_BONUS_RMB,TOTAL_SHARES,EX_DIVIDEND_DATE,ASSIGN_PROGRESS,PLAN_NOTICE_DATE'

def fetch(sym):
    code = sym.split('.')[0]
    params = {'reportName': 'RPT_SHAREBONUS_DET', 'columns': COLS,
              'filter': f'(SECURITY_CODE="{code}")', 'pageSize': '60',
              'sortColumns': 'REPORT_DATE', 'sortTypes': '-1'}
    url = BASE + '?' + urllib.parse.urlencode(params)
    for attempt in range(4):
        try:
            req = urllib.request.Request(url, headers=UA)
            d = json.load(urllib.request.urlopen(req, timeout=25))
            rows = (d.get('result') or {}).get('data') or []
            out = []
            for r in rows:
                rd = (r.get('REPORT_DATE') or '')[:10]
                if rd < '2022-06-30':
                    continue
                out.append({
                    'symbol': sym, 'report_date': rd,
                    'per10': r.get('PRETAX_BONUS_RMB'),
                    'total_shares': r.get('TOTAL_SHARES'),
                    'ex_date': (r.get('EX_DIVIDEND_DATE') or '')[:10] or None,
                    'progress': r.get('ASSIGN_PROGRESS'),
                })
            return out
        except Exception:
            time.sleep(1.2 + attempt * 1.5 + random.random())
    return []

res = []
with ThreadPoolExecutor(max_workers=4) as ex:
    futs = {ex.submit(fetch, s): s for s in syms}
    for i, f in enumerate(as_completed(futs)):
        res.extend(f.result())
        if i % 200 == 0:
            print('done', i, flush=True)

df = pd.DataFrame(res)
df.to_parquet('D:/repository/数据湖/分析产出/dividend_by_report.parquet', index=False)
print('rows', len(df), 'symbols', df.symbol.nunique())
print(df.head().to_string())
