"""修正版筛选：每股分红按【报告期归属】而非除权日，②⑤⑥⑪ 全部走会计年度口径。"""
import duckdb, pandas as pd

DB = 'D:/repository/数据湖/data/cnequity/duckdb/cnequity.duckdb'
con = duckdb.connect(':memory:')
con.execute(f"attach '{DB}' as src (read_only)")
q = lambda s: con.sql(s).df()
con.execute("create view divr as select * from read_parquet('D:/repository/数据湖/分析产出/dividend_by_report.parquet')")

# 已实施、有派现的行；按报告期年度汇总每股派现与分红总额
con.execute("""
create or replace temp view fy as
select symbol, year(cast(report_date as date)) y,
       sum(per10)/10 dps,
       sum(per10/10.0*total_shares)/1e8 amt_yi,
       count(*) n
from divr
where per10 is not null and per10>0 and progress='实施分配'
  and cast(report_date as date) between DATE '2023-01-01' and DATE '2025-12-31'
group by 1,2""")

con.execute("""
create or replace temp view yclose as
with lastd as (select year(trade_date) y, max(trade_date) d from src.daily_bars
               where trade_date between DATE '2023-01-01' and DATE '2025-12-31' group by 1)
select b.symbol, lastd.y, b.close from src.daily_bars b join lastd on b.trade_date=lastd.d""")
con.execute("""
create or replace temp view fin as
select symbol, report_period,
  max(case when item_code='net_profit' then item_value end) np,
  max(case when item_code='net_profit_yoy' then item_value end) np_yoy,
  max(case when item_code='roe' then item_value end) roe,
  max(case when item_code='eps' then item_value end) eps,
  max(case when item_code='ocf_per_share' then item_value end) ocfps,
  max(case when item_code='total_assets' then item_value end) ta,
  max(case when item_code='total_liabilities' then item_value end) tl,
  max(case when item_code='net_cash_operate' then item_value end) ocf
from src.financial_statement_items
where report_period in ('2022Q4','2023Q4','2024Q4','2025Q4','2026Q2') group by 1,2""")
con.execute("""
create or replace temp view ret12 as
with p as (select symbol,
  max(case when trade_date=DATE '2025-10-09' then qfq_close end) p0,
  max(case when trade_date=DATE '2026-10-09' then qfq_close end) p1
 from src.daily_bars_adj where trade_date in (DATE '2025-10-09', DATE '2026-10-09') group by 1)
select symbol, (p1/p0-1)*100 ret12m from p where p0>0 and p1 is not null""")
con.execute("""
create or replace temp view latest as
with lastd as (select max(trade_date) d from src.daily_bars)
select b.symbol, b.close px from src.daily_bars b join lastd on b.trade_date=lastd.d""")
# TTM：按除权日滚动 12 个月
con.execute("""
create or replace temp view ttm as
select symbol, sum(per10)/10 dps_ttm, sum(per10/10.0*total_shares)/1e8 amt_ttm
from divr
where per10 is not null and per10>0 and progress='实施分配'
  and cast(ex_date as date) > DATE '2025-10-09' and cast(ex_date as date) <= DATE '2026-10-09'
group by 1""")

raw = q("""
select b.symbol, b.name, b.list_date,
  d23.dps d23, d24.dps d24, d25.dps d25,
  d23.amt_yi a23, d24.amt_yi a24, d25.amt_yi a25,
  c23.close c23, c24.close c24, c25.close c25,
  f22.np np22, f23.np np23, f24.np np24, f25.np np25,
  f23.np_yoy y23, f24.np_yoy y24, f25.np_yoy y25,
  f23.roe roe23, f24.roe roe24, f25.roe roe25,
  f23.eps eps23, f24.eps eps24, f25.eps eps25,
  f23.ocfps ocfp23, f24.ocfps ocfp24, f25.ocfps ocfp25,
  f23.ocf cf23, f24.ocf cf24, f25.ocf cf25,
  f26.ta, f26.tl, r.ret12m, l.px, t.dps_ttm
from src.instruments b
left join fy d23 on d23.symbol=b.symbol and d23.y=2023
left join fy d24 on d24.symbol=b.symbol and d24.y=2024
left join fy d25 on d25.symbol=b.symbol and d25.y=2025
left join yclose c23 on c23.symbol=b.symbol and c23.y=2023
left join yclose c24 on c24.symbol=b.symbol and c24.y=2024
left join yclose c25 on c25.symbol=b.symbol and c25.y=2025
left join fin f22 on f22.symbol=b.symbol and f22.report_period='2022Q4'
left join fin f23 on f23.symbol=b.symbol and f23.report_period='2023Q4'
left join fin f24 on f24.symbol=b.symbol and f24.report_period='2024Q4'
left join fin f25 on f25.symbol=b.symbol and f25.report_period='2025Q4'
left join fin f26 on f26.symbol=b.symbol and f26.report_period='2026Q2'
left join ret12 r on r.symbol=b.symbol
left join latest l on l.symbol=b.symbol
left join ttm t on t.symbol=b.symbol
where b.asset_type='stock' and (b.delist_date is null or b.delist_date > DATE '2026-10-01')
""")

d = raw.copy()
for y in ('23','24','25'):
    d['p'+y] = d['d'+y]/d['eps'+y]*100
d['yld3'] = (d.d23/d.c23 + d.d24/d.c24 + d.d25/d.c25)/3*100
d['payout3'] = (d.p23+d.p24+d.p25)/3
d['cfdiv3'] = (d.ocfp23/d.d23 + d.ocfp24/d.d24 + d.ocfp25/d.d25)/3
d['roe3'] = (d.roe23+d.roe24+d.roe25)/3
d['debt'] = d.tl/d.ta*100
d['cfnp3'] = (d.cf23/d.np23 + d.cf24/d.np24 + d.cf25/d.np25)/3*100
d['cagr3'] = ((d.np25/d.np22)**(1/3)-1)*100
d['amt3'] = d.a23 + d.a24 + d.a25
d['yld_ttm'] = d.dps_ttm/d.px*100

d['c1'] = (d.d23>0)&(d.d24>0)&(d.d25>0)
d['c2'] = d.yld3 > 3.5
d['c3'] = (d.y23>0)&(d.y24>0)&(d.y25>0)
d['c4'] = d.debt < 60
d['c5'] = d.payout3.between(30,80)
d['c6'] = d.cfdiv3 > 1
d['c7'] = d.roe3 > 8
d['c8'] = d.cfnp3 > 80
d['c9'] = d.ret12m > -20
d['c10'] = d.cagr3 > 3
d['c11'] = d.amt3 > 10
KS = ['c1','c2','c3','c4','c5','c6','c7','c8','c9','c10','c11']
d['npass'] = d[KS].sum(axis=1)

THEIRS = ['600690.SH','600642.SH','000999.SZ','601000.SH','001286.SZ','600968.SH',
          '603699.SH','603766.SH','002911.SZ','600461.SH','605599.SH','600285.SH',
          '601033.SH','002170.SZ']
MINE = ['605599.SH','600285.SH','600461.SH','600642.SH','002911.SZ','600987.SH',
        '600060.SH','601298.SH','600483.SH']

# 漏斗
cur = d[d.c1]
print('①', len(cur))
for k, name in [('c2','②'),('c3','③'),('c4','④'),('c5','⑤'),('c6','⑥'),
                ('c7','⑦'),('c8','⑧'),('c9','⑨'),('c10','⑩'),('c11','⑪')]:
    cur = cur[cur[k]]
    print(name, len(cur))

res = d[d[KS].all(axis=1)].sort_values('yld_ttm', ascending=False)
print('\n=== 修正后最终名单', len(res), '===')
print(res[['symbol','name','yld_ttm','yld3','debt','payout3','cfdiv3','roe3','cfnp3','cagr3','amt3','ret12m']].round(2).to_string())

pd.set_option('display.width', 300); pd.set_option('display.max_columns', 80)
sel = d[d.symbol.isin(THEIRS + MINE)].copy()
sel['src'] = sel.symbol.apply(lambda s: 'A_双方' if s in THEIRS and s in MINE else ('B_仅对方' if s in THEIRS else 'C_仅我方'))
print('\n=== 明细 ===')
print(sel.sort_values(['src','yld_ttm'], ascending=[True,False])[
    ['symbol','name','src','yld_ttm','yld3','debt','payout3','cfdiv3','roe3','cfnp3','cagr3','amt3','ret12m','npass'] + KS
].round(2).to_string())
sel.to_csv('D:/repository/数据湖/分析产出/交叉验证明细.csv', index=False, encoding='utf-8-sig')
res.to_csv('D:/repository/数据湖/分析产出/高股息筛选结果_报告期口径.csv', index=False, encoding='utf-8-sig')

print('\n=== 逐条 ===')
for _, r in sel.sort_values('yld_ttm', ascending=False).iterrows():
    fails = [k for k in KS if not r[k]]
    print(f"{r.symbol} {r['name']:<5} {r['src']} 未过={fails if fails else '无'}")
