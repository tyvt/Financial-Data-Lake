# -*- coding: utf-8 -*-
"""修正回撤计算（复权+窗口内）+ 深市候选扩展"""
import duckdb, pandas as pd, numpy as np
pd.set_option('display.width',330); pd.set_option('display.max_columns',80); pd.set_option('display.max_rows',300)
BASE='2026-10-15'; ANN=np.sqrt(252)
con=duckdb.connect(':memory:')
con.execute("ATTACH 'D:/repository/数据湖/data/cnequity/duckdb/cnequity.duckdb' AS src (read_only)")

def build_ret(syms):
    q=",".join("'"+s+"'" for s in syms)
    px=con.execute(f"select symbol,trade_date,close from src.daily_bars where symbol in ({q}) and trade_date<=DATE '{BASE}' and close>0 order by 1,2").df()
    ca=con.execute(f"""select symbol,cast(ex_date as date) ex_date,coalesce(cash_dividend,0) cash,
     coalesce(bonus_ratio,0) bonus,coalesce(transfer_ratio,0) transfer from src.corporate_actions
     where symbol in ({q}) and cast(ex_date as date)<=DATE '{BASE}'""").df()
    rec=[]
    for s,g in px.groupby('symbol'):
        g=g.sort_values('trade_date').reset_index(drop=True)
        g['c_prev']=g['close'].shift(1); g['r_raw']=g['close']/g['c_prev']-1
        c=ca[ca.symbol==s]
        g=g.merge(c[['ex_date','cash','bonus','transfer']],left_on='trade_date',right_on='ex_date',how='left')
        prev_adj=(g['c_prev']-g['cash'].fillna(0))/(1+g['bonus'].fillna(0)+g['transfer'].fillna(0))
        g['r_adj']=np.where(g['ex_date'].notna(),g['close']/prev_adj-1,g['r_raw'])
        rec.append(g[['symbol','trade_date','r_adj']])
    return pd.concat(rec,ignore_index=True)

pool=pd.read_csv('高股息筛选结果_行业豁免版.csv',encoding='utf-8-sig')
mine=pd.read_csv('最终核心池_银行核验后.csv',encoding='utf-8-sig')[['symbol','结论']]
pool=pool.merge(mine,on='symbol',how='left'); pool['结论']=pool['结论'].fillna('未入选')
pool['板块']=np.where(pool.symbol.str.startswith('6'),'沪市','深市')
allr=build_ret(pool.symbol.tolist())

vr=[]
for s,g in allr.groupby('symbol'):
    r=g['r_adj'].dropna().tail(252)
    P=(1+r).cumprod()                      # 归一化复权净值
    mdd=float((P/P.cummax()-1).min())*100  # 窗口内最大回撤
    vr.append({'symbol':s,'vol':round(float(np.std(r,ddof=1))*ANN*100,2),
               'mdd':round(mdd,2),'vol_h1':round(float(np.std(r.tail(126),ddof=1))*ANN*100,2)})
vol=pd.DataFrame(vr)
q=",".join("'"+s+"'" for s in pool.symbol)
amt=con.execute(f"""with d as (select symbol,amount,row_number() over(partition by symbol order by trade_date desc) rk
 from src.daily_bars where symbol in ({q}) and trade_date<=DATE '{BASE}' and amount is not null)
 select symbol,avg(amount)/1e4 amt_wan from d where rk<=63 group by 1""").df()

d=pool.merge(vol,on='symbol').merge(amt,on='symbol')
d['yld_stab']=(d['d25']/d['px']*100).round(2)
d['r_stab']=(d['yld_stab']/d['yld3']).round(2)
d['r_ttm']=(d['yld_ttm']/d['yld3']).round(2)
d['c13']=d['amt_wan']>=5000; d['c14']=d['r_stab']<2

print("=== 23 只全池：波动率与近1年最大回撤（复权修正）===")
o=d[['symbol','name','板块','结论','vol','mdd','vol_h1','amt_wan','yld_stab','r_stab',]].sort_values('vol')
o.columns=['代码','名称','板块','状态','年化波动%','近1年最大回撤%','近半年波动%','日均成交(万)','稳态股息%','⑭倍数']
print(o.round(2).to_string(index=False))

print("\n=== 25% 通过名单（核心池口径）===")
core=d[(d.结论.isin(['保留','降级']))&(d.vol<25)&d.c13&d.c14].sort_values('vol')
print(core[['symbol','name','板块','vol','mdd','amt_wan','yld_stab']].round(2).to_string(index=False))
print(f"\n沪市 {len(core[core.板块=='沪市'])} 只 / 深市 {len(core[core.板块=='深市'])} 只")

# ---------- 深市候选扩展：从 283 只通过①②⑨的候选里找 ----------
cand=pd.read_csv('候选_①②⑨通过_283只.csv',encoding='utf-8-sig')
print(f"\n候选池(①②⑨通过) {len(cand)} 只，列: {list(cand.columns)[:12]}")
cand['板块']=np.where(cand.symbol.str.startswith('6'),'沪市','深市')
sz=cand[cand.板块=='深市']
print(f"其中深市 {len(sz)} 只")
