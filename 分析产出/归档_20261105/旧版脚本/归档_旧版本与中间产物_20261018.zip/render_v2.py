"""生成修正版（报告期归因）高股息报表。"""
import pandas as pd, html

d = pd.read_csv('D:/repository/数据湖/分析产出/高股息筛选结果_报告期口径.csv')
d = d.sort_values('yld_ttm', ascending=False)

for y in ('23', '24', '25'):
    d['cd' + y] = d['ocfp' + y] / d['d' + y]
    d['cn' + y] = d['cf' + y] / d['np' + y] * 100
    d['p' + y] = d['d' + y] / d['eps' + y] * 100

def cell(avg, ys, fmt):
    small = ' / '.join(fmt.format(x) if pd.notna(x) else '—' for x in ys)
    return f'<div class="avg">{fmt.format(avg)}</div><div class="yr">{small}</div>'

body = []
for _, r in d.iterrows():
    up = r.ret12m >= 0
    body.append(f"""<tr>
<td class="code">{r.symbol}</td><td class="name">{html.escape(str(r['name']))}</td>
<td class="num hi">{r.yld_ttm:.2f}%</td><td class="num">{r.yld3:.2f}%</td>
<td class="num">{cell(r.roe3, [r.roe23, r.roe24, r.roe25], '{:.2f}')}</td>
<td class="num">{cell(r.payout3, [r.p23, r.p24, r.p25], '{:.1f}')}</td>
<td class="num">{cell(r.cfdiv3, [r.cd23, r.cd24, r.cd25], '{:.2f}')}</td>
<td class="num">{cell(r.cfnp3, [r.cn23, r.cn24, r.cn25], '{:.0f}')}</td>
<td class="num">{r.debt:.1f}%</td>
<td class="num">{r.cagr3:+.1f}%</td><td class="num">{r.amt3:.1f}</td>
<td class="num {'up' if up else 'down'}">{r.ret12m:+.1f}%</td></tr>""")

funnel = [('① 2023–2025 连续分红（报告期口径）', 2701), ('② 3 年均股息率 > 3.5%', 341),
          ('③ 归母净利 3 年均正增长', 82), ('④ 资产负债率 < 60%', 41),
          ('⑤ 3 年均支付率 30–80%', 31), ('⑥ 现金流/分红 > 1', 29),
          ('⑦ 3 年均 ROE > 8%', 25), ('⑧ 现金流/净利 > 80%', 25),
          ('⑨ 近 12 月涨跌 > −20%', 23), ('⑩ 净利 CAGR > 3%', 23),
          ('⑪ 累计分红 > 10 亿元', 17)]
fhtml = ''.join(f'<li><span>{n}</span><b>{c}</b></li>' for n, c in funnel)

diff_rows = [
    ('605599.SH', '菜百股份', '双方命中', '—', 'ok'),
    ('600285.SH', '羚锐制药', '双方命中', '—', 'ok'),
    ('600461.SH', '洪城环境', '双方命中', '—', 'ok'),
    ('600642.SH', '申能股份', '双方命中', '⑪ 我方旧值 49.5→64.1亿（口径修正后与你的 64.1 一致）', 'ok'),
    ('002911.SZ', '佛燃能源', '双方命中', '⑪ 你的 18.9亿 vs 我方 15.7亿，疑你方多计一期', 'warn'),
    ('600690.SH', '海尔智家', '仅你方', '我方旧口径 ②=3.41% 不达标；按报告期归因 3.88% 达标', 'ok'),
    ('603766.SH', '隆鑫通用', '仅你方', '我方旧口径 ②=1.71% 严重低估（分红集中在次年）', 'ok'),
    ('603699.SH', '纽威股份', '仅你方', '我方旧口径 ②=3.32% 略低；报告期归因 4.57%', 'ok'),
    ('601000.SH', '唐山港', '仅你方', '⑪ 你方 47.4亿 = 4 个年度；实际 3 年 35.6亿（年报：每年 11.85亿）', 'warn'),
    ('000999.SZ', '华润三九', '仅你方', '② 3 年均 3.22%（1.5/49.73 + 1.32/44.34 + 1.04/28.46）不达 3.5%', 'bad'),
    ('001286.SZ', '陕西能源', '仅你方', '我方旧表按"2022 年前上市"过滤掉了它（2023-04 上市），属我方股票池过严', 'ok'),
    ('600968.SH', '海油发展', '仅你方', '我方旧口径 ②=3.02%；报告期归因 3.62% 达标', 'ok'),
    ('002170.SZ', '芭田股份', '仅你方', '我方旧口径 ②③⑤⑪ 均误判；报告期归因后全部达标', 'ok'),
    ('601033.SH', '永兴股份', '仅你方', '2024-01 上市，无 2023 年末收盘价 → ② 无法计算；其余 10 条达标', 'bad'),
    ('600987.SH', '航民股份', '仅我方(已剔除)', '⑪ 报告期口径 9.79亿 < 10亿，旧表 10.4亿 为除权日口径高估', 'bad'),
    ('600060.SH', '海信视像', '仅我方', '11 条全过，你方名单缺', 'warn'),
    ('601298.SH', '青岛港', '仅我方', '11 条全过，你方名单缺', 'warn'),
    ('600483.SH', '福能股份', '仅我方', '11 条全过，你方名单缺', 'warn'),
    ('002128.SZ', '电投能源', '仅我方', '11 条全过，你方名单缺', 'warn'),
    ('600428.SH', '中远海特', '仅我方', '11 条全过，你方名单缺', 'warn'),
]
tagtxt = {'ok': '口径修正', 'warn': '需复核', 'bad': '判定不通过'}
dhtml = ''.join(
    f'<tr><td class="code">{c}</td><td class="name">{n}</td><td class="num">{s}</td>'
    f'<td class="note-cell">{r}</td><td class="num"><span class="tag {k}">{tagtxt[k]}</span></td></tr>'
    for c, n, s, r, k in diff_rows)

doc = f"""<!DOCTYPE html><html lang="zh-CN"><head><meta charset="utf-8">
<title>高股息 11 条件筛选（报告期归因修正版）</title>
<style>
*{{box-sizing:border-box}}
body{{margin:0;padding:32px 28px 48px;background:#0d1117;color:#e6edf3;
 font-family:-apple-system,"Segoe UI","Microsoft YaHei",sans-serif}}
h1{{font-size:22px;margin:0 0 6px;font-weight:600}}
h2{{font-size:15px;margin:34px 0 12px;color:#c9d1d9;font-weight:600}}
.meta{{color:#8b949e;font-size:12.5px;line-height:1.8;margin-bottom:22px}}
.meta b{{color:#c9d1d9}}
.funnel{{display:flex;flex-wrap:wrap;gap:6px;list-style:none;padding:0;margin:0 0 26px}}
.funnel li{{background:#161b22;border:1px solid #21262d;border-radius:6px;padding:7px 11px;
 font-size:11.5px;color:#8b949e;display:flex;gap:8px;align-items:center}}
.funnel li b{{color:#58a6ff;font-size:14px;font-weight:600;font-variant-numeric:tabular-nums}}
table{{width:100%;border-collapse:collapse;font-size:13px;font-variant-numeric:tabular-nums}}
thead th{{text-align:right;padding:9px 8px;border-bottom:1px solid #30363d;color:#8b949e;
 font-size:11.5px;font-weight:500;line-height:1.5;white-space:nowrap;vertical-align:bottom}}
thead th:first-child,thead th:nth-child(2){{text-align:left}}
.sub{{color:#484f58;font-size:10px}}
tbody td{{padding:11px 8px;border-bottom:1px solid #161b22;text-align:right;white-space:nowrap}}
tbody td.code{{text-align:left;color:#8b949e;font-size:12px}}
tbody td.name{{text-align:left;font-weight:600}}
tbody tr:hover{{background:#11161d}}
.avg{{font-weight:700;font-size:13.5px}}
.yr{{color:#6e7681;font-size:10.5px;margin-top:2px}}
.hi{{color:#f0883e;font-weight:700;font-size:14.5px}}
.up{{color:#f85149;font-weight:600}}
.down{{color:#3fb950;font-weight:600}}
.note-cell{{text-align:left!important;white-space:normal;color:#8b949e;font-size:12px;line-height:1.6;max-width:520px}}
.tag{{font-size:10.5px;padding:2px 7px;border-radius:10px;white-space:nowrap}}
.tag.ok{{background:#1f3a2a;color:#3fb950}}
.tag.warn{{background:#3a3218;color:#d29922}}
.tag.bad{{background:#3a1f1f;color:#f85149}}
.note{{margin-top:26px;font-size:11.5px;color:#6e7681;line-height:1.9;max-width:1180px}}
.note b{{color:#8b949e}}
code{{background:#161b22;padding:1px 5px;border-radius:4px;font-size:11px;color:#79c0ff}}
</style></head><body>
<h1>高股息 11 条件筛选 · 报告期归因修正版</h1>
<div class="meta">命中 <b>{len(d)}</b> 只　·　按<b>当前股息率（TTM）</b>降序　·　价格区间 2025-10-09 → 2026-10-09（前复权）　·　负债率基准 2026 中报<br>
修正点：每股分红由「除权日所在年」改为<b>按报告期归属</b>（东财 <code>RPT_SHAREBONUS_DET</code>），②⑤⑥⑪ 全部重算</div>
<ul class="funnel">{fhtml}</ul>
<table><thead><tr>
<th>代码</th><th>名称</th><th>当前股息率<span class="sub">TTM</span></th><th>3年均股息率</th>
<th>ROE<span class="sub">加权 %</span></th><th>股息支付率<span class="sub">%</span></th>
<th>现金流/分红<span class="sub">倍</span></th><th>现金流/净利<span class="sub">%</span></th>
<th>资产负债率<span class="sub">2026H1</span></th><th>归母净利CAGR<span class="sub">22→25</span></th>
<th>累计分红<span class="sub">亿元</span></th><th>近12月涨跌</th>
</tr></thead><tbody>{''.join(body)}</tbody></table>

<h2>与你截图名单的逐条对比</h2>
<table><thead><tr><th>代码</th><th>名称</th><th>状态</th><th style="text-align:left">差异原因</th><th>归类</th></tr></thead>
<tbody>{dhtml}</tbody></table>

<div class="note">
<b>结论</b>：14 只中 12 只经复核完全成立；华润三九（② 3.22%）与永兴股份（无 2023 年末价格，② 无法计算）不成立。<br>
<b>我方上一版错误</b>：用除权日年份归集每股派现，导致高送转/中期分红多的公司股息率被系统性低估（海尔 3.41→3.88、隆鑫 1.71→3.56、纽威 3.32→4.57、海油 3.02→3.62），
分红总额同样被错配（申能 49.5→64.1 亿）。另因「2022 年前上市」过滤，误排除了陕西能源（2023-04 上市）。<br>
<b>你方待核</b>：唐山港 47.4 亿实为 4 个年度之和（真实每年 11.85 亿，年报原文）；佛燃能源 18.9 亿与我方 15.7 亿差 3.2 亿，疑多计一期。<br>
<b>口径</b>：ROE 加权、EPS 基本、经营现金流按每股口径；⑧ 为合并口径经营现金流净额/归母净利润；⑪ 为报告期现金分红总额合计。
</div></body></html>"""

open('D:/repository/数据湖/分析产出/高股息筛选结果_修正版.html', 'w', encoding='utf-8').write(doc)
print('ok', len(d))
