# -*- coding: utf-8 -*-
"""深市子池分红可持续性底线核验：连续分红 / 支付率<100% / OCF÷分红>1"""
import duckdb, pandas as pd, numpy as np
pd.set_option('display.width',300); pd.set_option('display.max_columns',40)
con=duckdb.connect(':memory:')
con.execute("ATTACH 'D:/repository/数据湖/data/cnequity/duckdb/cnequity.duckdb' AS src (read_only)")

cand={'000651.SZ':'格力电器','000538.SZ':'云南白药','000895.SZ':'双汇发展',
      '000001.SZ':'平安银行','002966.SZ':'苏州银行','000333.SZ':'美的集团',
      '002032.SZ':'苏泊尔','000429.SZ':'粤高速A','001965.SZ':'招商公路'}
syms=list(cand); q=",".join("'"+s+"'" for s in syms)

# ---- 分红（报告期口径）----
div=con.execute(f"""
select symbol, year(cast(report_date as date)) y, sum(per10)/10 dps,
       sum(per10/10.0*total_shares)/1e8 amt
from read_parquet('dividend_by_report.parquet')
where symbol in ({q}) and per10 is not null and per10>0 and progress='实施分配'
  and cast(report_date as date) between DATE '2022-01-01' and DATE '2025-12-31'
group by 1,2 order by 1,2""").df()

# ---- 净利 & 经营现金流 ----
fin=con.execute(f"""
select symbol, year(cast(concat(substr(report_period,1,4),'-12-31') as date)) y,
  max(case when item_code='net_profit' then item_value end)/1e8 np,
  max(case when item_code='net_cash_operate' then item_value end)/1e8 ocf
from src.financial_statement_items
where symbol in ({q}) and report_period like '%Q4'
  and substr(report_period,1,4) between '2022' and '2025'
group by 1,2 order by 1,2""").df()

d=div.merge(fin,on=['symbol','y'],how='outer').sort_values(['symbol','y'])
d['name']=d.symbol.map(cand)
d['payout']=(d.amt/d.np*100).round(1)
d['ocf_div']=(d.ocf/d.amt).round(2)

print("=== 逐年明细（2022-2025，报告期口径）===")
print(d[['symbol','name','y','dps','amt','np','ocf','payout','ocf_div']].round(3).to_string(index=False))

# ---- 近3年（2023-2025）汇总判定 ----
print("\n=== 三条底线判定（2023-2025）===")
rows=[]
for s,n in cand.items():
    g=d[(d.symbol==s)&(d.y.between(2023,2025))]
    if len(g)==0: rows.append({'标的':n,'连续分红':'无数据'}); continue
    yrs=set(g.y.tolist())
    cont = yrs=={2023,2024,2025}
    pay3=round(float(g.amt.sum()/g.np.sum()*100),1) if g.np.sum()>0 else np.nan
    pd_max=round(float(g.payout.max()),1)
    ocfd=round(float(g.ocf.sum()/g.amt.sum()),2) if g.amt.sum()>0 else np.nan
    rows.append({'标的':n,'代码':s,'连续分红':'✓ 三年齐全' if cont else f'✗ 缺{2023,2024,2025}-yrs',
                 '三年累计支付率%':pay3,'单年最高支付率%':pd_max,
                 '三年OCF/分红':ocfd,
                 '①连续分红':cont,'②支付率<100%':pd_max<100,'③OCF/分红>1':ocfd>1,
                 '通过数':int(cont)+int(pd_max<100)+int(ocfd>1)})
r=pd.DataFrame(rows)
print(r.to_string(index=False))
r.to_csv('深市子池_分红底线核验.csv',index=False,encoding='utf-8-sig')
