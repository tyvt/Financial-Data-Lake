# -*- coding: utf-8 -*-
"""最终版：23只全池 + 复权修正 + 三标准 + 沪深分布 + 阈值敏感性"""
import duckdb, pandas as pd, numpy as np
pd.set_option('display.width',330); pd.set_option('display.max_columns',80); pd.set_option('display.max_rows',200)
BASE='2026-10-15'; ANN=np.sqrt(252)

con=duckdb.connect(':memory:')
con.execute("ATTACH 'D:/repository/数据湖/data/cnequity/duckdb/cnequity.duckdb' AS src (read_only)")

pool=pd.read_csv('高股息筛选结果_行业豁免版.csv',encoding='utf-8-sig')
print(f"11条高股息全池（含行业豁免）: {len(pool)} 只")

# 排雷结论
mine=pd.read_csv('最终核心池_银行核验后.csv',encoding='utf-8-sig')[['symbol','结论']]
pool=pool.merge(mine,on='symbol',how='left')
pool['结论']=pool['结论'].fillna('未排雷')

syms=pool.symbol.tolist(); q=",".join("'"+s+"'" for s in syms)
pool['板块']=np.where(pool.symbol.str.startswith(('6',)),'沪市','深市')

# ---- 重建复权收益率 ----
px=con.execute(f"select symbol,trade_date,close from src.daily_bars where symbol in ({q}) and trade_date<=DATE '{BASE}' and close>0 order by 1,2").df()
ca=con.execute(f"""select symbol,cast(ex_date as date) ex_date,coalesce(cash_dividend,0) cash,
 coalesce(bonus_ratio,0) bonus,coalesce(transfer_ratio,0) transfer from src.corporate_actions
 where symbol in ({q}) and cast(ex_date as date)<=DATE '{BASE}'""").df()

rec=[]
for s,g in px.groupby('symbol'):
    g=g.sort_values('trade_date').reset_index(drop=True)
    g['c_prev']=g['close'].shift(1)
    g['r_raw']=g['close']/g['c_prev']-1
    c=ca[ca.symbol==s]
    g=g.merge(c[['ex_date','cash','bonus','transfer']],left_on='trade_date',right_on='ex_date',how='left')
    g['has_ex']=g['ex_date'].notna()
    prev_adj=(g['c_prev']-g['cash'].fillna(0))/(1+g['bonus'].fillna(0)+g['transfer'].fillna(0))
    g['r_adj']=np.where(g['has_ex'],g['close']/prev_adj-1,g['r_raw'])
    rec.append(g[['symbol','trade_date','close','r_raw','r_adj']])
allr=pd.concat(rec,ignore_index=True)

vr=[]
for s,g in allr.groupby('symbol'):
    r=g['r_adj'].dropna().tail(252)
    vr.append({'symbol':s,'vol':round(float(np.std(r,ddof=1))*ANN*100,2),
               'vol_h1':round(float(np.std(r.tail(126),ddof=1))*ANN*100,2),
               'vol_2y':round(float(np.std(r.tail(504),ddof=1))*ANN*100,2) if len(g)>=504 else np.nan,
               'mdd':round(float((g['close']/g['close'].cummax()-1).tail(252).min())*100,2)})
vol=pd.DataFrame(vr)

amt=con.execute(f"""with d as (select symbol,amount,row_number() over(partition by symbol order by trade_date desc) rk
 from src.daily_bars where symbol in ({q}) and trade_date<=DATE '{BASE}' and amount is not null)
 select symbol,avg(amount)/1e4 amt_wan from d where rk<=63 group by 1""").df()

d=pool.merge(vol,on='symbol').merge(amt,on='symbol')
d['yld_stab']=(d['d25']/d['px']*100).round(2)
d['r_ttm']=(d['yld_ttm']/d['yld3']).round(2)
d['r_stab']=(d['yld_stab']/d['yld3']).round(2)

for th,lab in [(25,'c12_25'),(22,'c12_22'),(28,'c12_28'),(30,'c12_30')]:
    d[lab]=d['vol']<th
d['c13']=d['amt_wan']>=5000
d['c14']=d['r_stab']<2
d['pass25']=d.c12_25&d.c13&d.c14

print("\n=== 全部 23 只（按年化波动率升序）===")
o=d[['symbol','name','板块','industry_name','结论','vol','mdd','amt_wan','yld_ttm','yld_stab','yld3','r_ttm','r_stab','c12_25','c13','c14','pass25']].sort_values('vol')
o.columns=['代码','名称','板块','行业','排雷','年化波动%','近1年回撤%','日均成交(万)','TTM股息%','稳态股息%','3年均值%','倍数TTM','倍数稳态','⑫25','⑬','⑭','全通过']
print(o.round(2).to_string(index=False))

print("\n=== 阈值敏感性（⑬⑭ 达标前提下）===")
for th in [20,22,25,26,28,30,32]:
    m=d[(d.vol<th)&d.c13&d.c14].sort_values('vol')
    sz=m.groupby('板块').size().to_dict()
    print(f"  {th:>2}% -> {len(m):2d} 只  沪{sz.get('沪市',0)}/深{sz.get('深市',0)}: {', '.join(m['name'])}")

print("\n=== 25% 通过名单的板块分布 ===")
p=d[d.pass25]
for b in ['沪市','深市']:
    sub=p[p.板块==b]
    print(f"  {b}: {len(sub)} 只 -> {', '.join(sub.name) if len(sub) else '【无】'}")
print(f"\n  深市最低波动标的: {d[d.板块=='深市'].sort_values('vol').iloc[0]['name']} {d[d.板块=='深市'].sort_values('vol').iloc[0]['vol']}%")

d.to_csv('打新底仓_三条标准_全池.csv',index=False,encoding='utf-8-sig')
print("\n已导出 打新底仓_三条标准_全池.csv")
