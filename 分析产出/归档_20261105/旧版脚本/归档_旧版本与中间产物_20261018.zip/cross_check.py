import duckdb, pandas as pd

DB = 'D:/repository/数据湖/data/cnequity/duckdb/cnequity.duckdb'
con = duckdb.connect(DB, read_only=True)
q = lambda s: con.sql(s).df()

THEIRS = ['600690.SH','600642.SH','000999.SZ','601000.SH','001286.SZ','600968.SH',
          '603699.SH','603766.SH','002911.SZ','600461.SH','605599.SH','600285.SH',
          '601033.SH','002170.SZ']
MINE = ['605599.SH','600285.SH','600461.SH','600642.SH','002911.SZ','600987.SH',
        '600060.SH','601298.SH','600483.SH']

con.execute("""
create or replace temp view dps as
select symbol, year(ex_date) y, sum(cash_dividend) dps, count(*) n from corporate_actions
where action_type='cash_dividend' and cash_dividend is not null
  and ex_date between DATE '2023-01-01' and DATE '2025-12-31' group by 1,2""")
con.execute("""
create or replace temp view yclose as
with lastd as (select year(trade_date) y, max(trade_date) d from daily_bars
               where trade_date between DATE '2023-01-01' and DATE '2025-12-31' group by 1)
select b.symbol, lastd.y, b.close from daily_bars b join lastd on b.trade_date=lastd.d""")
con.execute("""
create or replace temp view fin as
select symbol, report_period,
  max(case when item_code='net_profit' then item_value end) np,
  max(case when item_code='net_profit_yoy' then item_value end) np_yoy,
  max(case when item_code='roe' then item_value end) roe,
  max(case when item_code='eps' then item_value end) eps,
  max(case when item_code='ocf_per_share' then item_value end) ocfps,
  max(case when item_code='total_assets' then item_value end) ta,
  max(case when item_code='total_liabilities' then item_value end) tl,
  max(case when item_code='net_cash_operate' then item_value end) ocf,
  max(case when item_code='revenue' then item_value end) rev
from financial_statement_items
where report_period in ('2022Q4','2023Q4','2024Q4','2025Q4','2026Q2') group by 1,2""")
con.execute("""
create or replace temp view ret12 as
with p as (select symbol,
  max(case when trade_date=DATE '2025-10-09' then qfq_close end) p0,
  max(case when trade_date=DATE '2026-10-09' then qfq_close end) p1
 from daily_bars_adj where trade_date in (DATE '2025-10-09', DATE '2026-10-09') group by 1)
select symbol, (p1/p0-1)*100 ret12m from p where p0>0 and p1 is not null""")
con.execute("""
create or replace temp view latest as
with lastd as (select max(trade_date) d from daily_bars)
select b.symbol, b.close px from daily_bars b join lastd on b.trade_date=lastd.d""")
con.execute("""
create or replace temp view dps_ttm as
select symbol, sum(cash_dividend) dps_ttm from corporate_actions
where action_type='cash_dividend' and ex_date > DATE '2025-10-09' and ex_date <= DATE '2026-10-09'
group by 1""")
con.execute("""
create or replace temp view div_total as
with sh as (
  select symbol, total_shares, change_date,
    row_number() over (partition by symbol order by change_date desc) rn
  from share_structure where total_shares is not null),
ca as (select c.symbol, c.cash_dividend * coalesce(s.total_shares, f.total_shares) amt
  from corporate_actions c
  asof left join share_structure s on c.symbol = s.symbol and c.ex_date >= s.change_date
  left join sh f on f.symbol = c.symbol and f.rn = 1
  where c.action_type='cash_dividend' and c.cash_dividend is not null
    and c.ex_date between DATE '2023-01-01' and DATE '2025-12-31')
select symbol, sum(amt)/1e8 amt_yi from ca group by 1""")

raw = q("""
select b.symbol, b.name, d23.dps d23, d24.dps d24, d25.dps d25,
  d23.n n23, d24.n n24, d25.n n25,
  c23.close c23, c24.close c24, c25.close c25,
  f22.np np22, f23.np np23, f24.np np24, f25.np np25,
  f23.np_yoy y23, f24.np_yoy y24, f25.np_yoy y25,
  f23.roe roe23, f24.roe roe24, f25.roe roe25,
  f23.eps eps23, f24.eps eps24, f25.eps eps25,
  f23.ocf cf23, f24.ocf cf24, f25.ocf cf25,
  f23.ocfps ocfp23, f24.ocfps ocfp24, f25.ocfps ocfp25,
  f26.ta, f26.tl, r.ret12m, l.px, t.dps_ttm, dt.amt_yi
from instruments b
left join dps d23 on d23.symbol=b.symbol and d23.y=2023
left join dps d24 on d24.symbol=b.symbol and d24.y=2024
left join dps d25 on d25.symbol=b.symbol and d25.y=2025
left join yclose c23 on c23.symbol=b.symbol and c23.y=2023
left join yclose c24 on c24.symbol=b.symbol and c24.y=2024
left join yclose c25 on c25.symbol=b.symbol and c25.y=2025
left join fin f22 on f22.symbol=b.symbol and f22.report_period='2022Q4'
left join fin f23 on f23.symbol=b.symbol and f23.report_period='2023Q4'
left join fin f24 on f24.symbol=b.symbol and f24.report_period='2024Q4'
left join fin f25 on f25.symbol=b.symbol and f25.report_period='2025Q4'
left join fin f26 on f26.symbol=b.symbol and f26.report_period='2026Q2'
left join ret12 r on r.symbol=b.symbol
left join latest l on l.symbol=b.symbol
left join dps_ttm t on t.symbol=b.symbol
left join div_total dt on dt.symbol=b.symbol
""")

sym = THEIRS + [s for s in MINE if s not in THEIRS]
d = raw[raw.symbol.isin(sym)].copy()
for y in ('23','24','25'):
    d['p'+y] = d['d'+y]/d['eps'+y]*100
    d['cd'+y] = d['ocfp'+y]/d['d'+y]
    d['cn'+y] = d['cf'+y]/d['np'+y]*100
d['yld3'] = (d.d23/d.c23 + d.d24/d.c24 + d.d25/d.c25)/3*100
d['payout3'] = (d.p23+d.p24+d.p25)/3
d['cfdiv3'] = (d.cd23+d.cd24+d.cd25)/3
d['roe3'] = (d.roe23+d.roe24+d.roe25)/3
d['cfnp3'] = (d.cn23+d.cn24+d.cn25)/3
d['debt'] = d.tl/d.ta*100
d['cagr3'] = ((d.np25/d.np22)**(1/3)-1)*100
d['yld_ttm'] = d.dps_ttm/d.px*100
d['c1'] = (d.d23>0)&(d.d24>0)&(d.d25>0)
d['c3'] = (d.y23>0)&(d.y24>0)&(d.y25>0)
d['c4'] = d.debt < 60
d['c5'] = d.payout3.between(30,80)
d['c6'] = d.cfdiv3 > 1
d['c7'] = d.roe3 > 8
d['c8'] = d.cfnp3 > 80
d['c9'] = d.ret12m > -20
d['c10'] = d.cagr3 > 3
d['c11'] = d.amt_yi > 10
d['npass'] = d[['c1','c3','c4','c5','c6','c7','c8','c9','c10','c11']].sum(axis=1)
d['src'] = d.symbol.apply(lambda s: '双方' if s in THEIRS and s in MINE else ('仅对方' if s in THEIRS else '仅我方'))

cols = ['symbol','name','src','c23','c24','c25','ocfp23','ocfp24','ocfp25','yld_ttm','yld3','debt','payout3','cfdiv3','roe3','cfnp3','cagr3','amt_yi','ret12m','npass',
        'c1','c3','c4','c5','c6','c7','c8','c9','c10','c11',
        'd23','d24','d25','eps23','eps24','eps25','np22','np23','np24','np25','y23','y24','y25',
        'roe23','roe24','roe25','ta','tl']
out = d[cols].sort_values(['src','yld_ttm'], ascending=[True, False])
pd.set_option('display.width', 250)
print(out[['symbol','name','src','yld_ttm','yld3','debt','payout3','cfdiv3','roe3','cfnp3','cagr3','amt_yi','ret12m','npass']].round(2).to_string())
print()
for _, r in out.iterrows():
    fails = [k for k in ['c1','c3','c4','c5','c6','c7','c8','c9','c10','c11'] if not r[k]]
    print(f"{r.symbol} {r['name']:<6} [{r.src}] 未过={fails}")
    print(f"   dps23/24/25={r.d23:.3f}/{r.d24:.3f}/{r.d25:.3f}  年末价={r.c23}/{r.c24}/{r.c25}  股息率3y={r.yld3:.2f}%")
    print(f"   net_profit {float(r['np22'])/1e8:.2f}->{r.np23/1e8:.2f}->{r.np24/1e8:.2f}->{r.np25/1e8:.2f}亿  yoy={r.y23}/{r.y24}/{r.y25}  cagr={r.cagr3:.1f}%")
    print(f"   eps={r.eps23}/{r.eps24}/{r.eps25}  payout={r.payout3:.1f}%  roe={r.roe3:.1f}%  debt={r.debt:.1f}%  cfdiv={r.cfdiv3:.2f}  cfnp={r.cfnp3:.0f}%  amt={r.amt_yi:.1f}亿")
out.to_csv('D:/repository/数据湖/分析产出/交叉验证明细.csv', index=False, encoding='utf-8-sig')
