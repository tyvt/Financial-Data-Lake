# -*- coding: utf-8 -*-
"""敏感性与口径稳健性检验"""
import duckdb, pandas as pd, numpy as np, math
BASE='2026-10-15'; ANN=math.sqrt(252)
con=duckdb.connect(':memory:')
con.execute("ATTACH 'D:/repository/数据湖/data/cnequity/duckdb/cnequity.duckdb' AS src (read_only)")
d=pd.read_csv('打新底仓_低波流动性复算.csv',encoding='utf-8-sig')
syms=d.symbol.tolist()
q=",".join("'"+s+"'" for s in syms)

# ---- 多窗口波动率稳健性 ----
px=con.execute(f"""select symbol,trade_date,qfq_close from src.daily_bars_adj
 where symbol in ({q}) and trade_date<=DATE '{BASE}' and qfq_close>0 order by symbol,trade_date""").df()
px['ret']=px.groupby('symbol')['qfq_close'].pct_change()

# 复权精度检查
print("=== 前复权精度 (adj_is_exact=False 占比) ===")
print(con.execute(f"""select symbol, round(sum(case when adj_is_exact then 0 else 1 end)*100.0/count(*),1) pct_no_exact
 from src.daily_bars_adj where symbol in ({q}) and trade_date>=DATE '2023-10-15' group by 1 order by 2 desc limit 5""").df().to_string(index=False))

rows=[]
for s,g in px.groupby('symbol'):
    r=g.dropna(subset=['ret'])
    rec={'symbol':s}
    for label,n in [('vol_1y',252),('vol_2y',504),('vol_3y',756),('vol_h1',126)]:
        rec[label]=round(float(np.std(r['ret'].tail(n),ddof=1))*ANN*100,2) if len(r)>=n*0.8 else np.nan
    rows.append(rec)
w=pd.DataFrame(rows)
d=d.merge(w,on='symbol',how='left')

# ---- ⑭ 双口径 ----
d['yld_stable']=(d['d25']/d['px']*100).round(2)     # 最近完整年度(2025)分红 / 现价
d['r_ttm']=(d['yld_ttm']/d['yld3']).round(2)        # 滚动12个月实施口径
d['r_stable']=(d['yld_stable']/d['yld3']).round(2)  # 稳态口径

pd.set_option('display.width',320); pd.set_option('display.max_columns',80); pd.set_option('display.max_rows',100)

print("\n=== ⑫ 波动率的多窗口稳健性（%）===")
t=d[['name','vol_1y','vol_h1','vol_2y','vol_3y']].copy()
t.columns=['名称','近1年','近半年','近2年','近3年']
print(t.sort_values('近1年').round(2).to_string(index=False))

print("\n=== ⑭ 股息率倍数：TTM实施口径 vs 稳态年度口径 ===")
t=d[['name','yld_ttm','yld_stable','yld3','r_ttm','r_stable']].copy()
t.columns=['名称','TTM实施%','稳态年度%','3年均值%','倍数(TTM)','倍数(稳态)']
t['⑭(TTM)']=np.where(d.r_ttm<2,'通过','剔除'); t['⑭(稳态)']=np.where(d.r_stable<2,'通过','剔除')
print(t.sort_values('倍数(稳态)',ascending=False).round(2).to_string(index=False))

# ---- 阈值敏感性 ----
print("\n=== ⑫ 阈值敏感性（⑬⑭ 已达标前提下）===")
grid={}
for th in [20,22,25,28,30]:
    m=d[(d.vol_1y<th)&(d.c13)&(d.r_stable<2)]
    grid[f'{th}%']=[f"{r['name']}({r.vol_1y})" for _,r in m.sort_values('vol_1y').iterrows()]
for k,v in grid.items():
    print(f"  {k:>4} -> {len(v):2d} 只: {', '.join(v)}")

d.to_csv('打新底仓_低波流动性复算.csv',index=False,encoding='utf-8-sig')
