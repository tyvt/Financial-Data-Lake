import duckdb, pandas as pd
pd.set_option('display.width', 250); pd.set_option('display.max_columns', 60)
con = duckdb.connect(':memory:')
con.execute("ATTACH 'D:/repository/数据湖/data/cnequity/duckdb/cnequity.duckdb' AS src (read_only)")
q = """
select report_period,
  max(case when item_code='revenue' then item_value end)/1e8 as rev_yi,
  max(case when item_code='operating_cost' then item_value end)/1e8 as cost_yi,
  max(case when item_code='net_profit' then item_value end)/1e8 as np_yi,
  max(case when item_code='net_profit_deducted' then item_value end)/1e8 as npd_yi,
  max(case when item_code='net_cash_operate' then item_value end)/1e8 as ocf_yi,
  max(case when item_code='capex' then item_value end)/1e8 as capex_yi,
  max(case when item_code='accounts_receivable' then item_value end)/1e8 as ar_yi,
  max(case when item_code='inventory' then item_value end)/1e8 as inv_yi,
  max(case when item_code='monetary_funds' then item_value end)/1e8 as cash_yi,
  max(case when item_code='total_assets' then item_value end)/1e8 as ta_yi,
  max(case when item_code='total_liabilities' then item_value end)/1e8 as tl_yi,
  max(case when item_code='gross_margin' then item_value end) as gm
from src.financial_statement_items
where symbol='002170.SZ' and statement_type is not null
  and report_period >= '2022Q1'
group by 1 order by 1
"""
df = con.execute(q).df()
df['debt'] = (df.tl_yi/df.ta_yi*100).round(2)
df['gm_pct'] = (df.gm*100).round(2) if df.gm.max() < 2 else df.gm.round(2)
print(df.round(3).to_string(index=False))
