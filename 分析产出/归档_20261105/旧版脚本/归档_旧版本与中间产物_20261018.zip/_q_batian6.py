import duckdb, pandas as pd
pd.set_option('display.width',250)
con = duckdb.connect(':memory:')
con.execute("ATTACH 'D:/repository/数据湖/data/cnequity/duckdb/cnequity.duckdb' AS src (read_only)")
# 归母 vs 合并净利 差额 → 少数股东损益；再看 营业利润/利润总额/所得税 结构
print(con.execute("""
select report_period rp,
  round(max(case when item_code='total_profit' then item_value end)/1e8,4) 利润总额,
  round(max(case when item_code='income_tax' then item_value end)/1e8,4) 所得税,
  round(max(case when item_code='net_profit' then item_value end)/1e8,4) 归母净利,
  round(max(case when item_code='net_profit_deducted' then item_value end)/1e8,4) 扣非,
  round((max(case when item_code='net_profit' then item_value end)
        -max(case when item_code='net_profit_deducted' then item_value end))/1e8,4) 非经常性,
  round((max(case when item_code='net_profit' then item_value end)
        -max(case when item_code='net_profit_deducted' then item_value end))
        /max(case when item_code='net_profit' then item_value end)*100,2) 非经常占比pct
from src.financial_statement_items where symbol='002170.SZ' and report_period>='2023Q1'
group by 1 order by 1""").df().to_string(index=False))
print("\n=== 实缴税率 ===")
print(con.execute("""
select report_period rp,
  round(max(case when item_code='income_tax' then item_value end)
       /max(case when item_code='total_profit' then item_value end)*100,2) 实际税率pct
from src.financial_statement_items where symbol='002170.SZ' and report_period>='2024Q1'
group by 1 order by 1""").df().to_string(index=False))
