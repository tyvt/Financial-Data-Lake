import duckdb, pandas as pd
pd.set_option('display.width', 250); pd.set_option('display.max_columns', 60)
con = duckdb.connect(':memory:')
con.execute("ATTACH 'D:/repository/数据湖/data/cnequity/duckdb/cnequity.duckdb' AS src (read_only)")
q = """
select report_period rp,
  max(case when item_code='revenue' then item_value end)/1e8 rev,
  max(case when item_code='operating_cost' then item_value end)/1e8 cst,
  max(case when item_code='sale_expense' then item_value end)/1e8 sellx,
  max(case when item_code='manage_expense' then item_value end)/1e8 mgmtx,
  max(case when item_code='finance_expense' then item_value end)/1e8 finx,
  max(case when item_code='operating_profit' then item_value end)/1e8 opx,
  max(case when item_code='total_profit' then item_value end)/1e8 tpx,
  max(case when item_code='income_tax' then item_value end)/1e8 taxx,
  max(case when item_code='net_profit' then item_value end)/1e8 npx,
  max(case when item_code='net_profit_deducted' then item_value end)/1e8 npdx,
  max(case when item_code='net_cash_operate' then item_value end)/1e8 ocfx,
  max(case when item_code='net_cash_invest' then item_value end)/1e8 icfx,
  max(case when item_code='net_cash_finance' then item_value end)/1e8 fcfx,
  max(case when item_code='accounts_receivable' then item_value end)/1e8 arx,
  max(case when item_code='inventory' then item_value end)/1e8 invx,
  max(case when item_code='monetary_funds' then item_value end)/1e8 cashx
from src.financial_statement_items where symbol='002170.SZ' and report_period>='2024Q1'
group by 1 order by 1
"""
df = con.execute(q).df().set_index('rp')
# 单季还原
rows=[]
for y in [2024,2025,2026]:
    prev=None
    for qi in [1,2,3,4]:
        rp=f"{y}Q{qi}"
        if rp not in df.index: break
        cur=df.loc[rp]
        if qi==1: sq=cur.copy()
        else: sq=cur-df.loc[f"{y}Q{qi-1}"]
        sq['rp']=rp; sq['q']=qi; rows.append(sq)
        prev=cur
sq=pd.DataFrame(rows).set_index('rp')
flow=['rev','cst','sellx','mgmtx','finx','opx','tpx','taxx','npx','npdx','ocfx','icfx','fcfx']
print("=== 单季（亿元）===")
print(sq[['q']+flow].round(3).to_string())
print()
print("=== 单季毛利率 / 期间费用率 / 净利率 / OCF÷NP（%）===")
out=pd.DataFrame({'q':sq.q})
out['毛利率']=((sq.rev-sq.cst)/sq.rev*100).round(2)
out['销售费用率']=(sq.sellx/sq.rev*100).round(2)
out['管理费用率']=(sq.mgmtx/sq.rev*100).round(2)
out['财务费用率']=(sq.finx/sq.rev*100).round(2)
out['净利率']=(sq.npx/sq.rev*100).round(2)
out['OCF/NP']=(sq.ocfx/sq.npx*100).round(1)
print(out.to_string())
print()
print("=== 期末余额（亿元）===")
bal=['arx','invx','cashx']
print(df[bal].round(3).to_string())
