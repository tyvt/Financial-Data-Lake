# -*- coding: utf-8 -*-
import pandas as pd, numpy as np

port=[
 dict(mkt='沪',name='洪城环境',sym='600461.SH',ind='环保',vol=19.00,mdd=-13.88,amt=10502,yld=5.19,pay=47.5,ocfd=3.32),
 dict(mkt='沪',name='青岛港',  sym='601298.SH',ind='交运',vol=20.90,mdd=-18.39,amt=10742,yld=3.50,pay=40.0,ocfd=2.75),
 dict(mkt='沪',name='沪农商行',sym='601825.SH',ind='银行',vol=21.30,mdd=-19.56,amt=22663,yld=5.03,pay=32.7,ocfd=6.76),
 dict(mkt='沪',name='唐山港',  sym='601000.SH',ind='交运',vol=22.18,mdd=-13.02,amt=20550,yld=4.22,pay=60.3,ocfd=1.86),
 dict(mkt='沪',name='农业银行',sym='601288.SH',ind='银行',vol=23.62,mdd=-28.87,amt=260680,yld=3.45,pay=32.1,ocfd=20.93),
 dict(mkt='深',name='格力电器',sym='000651.SZ',ind='家电',vol=15.68,mdd=-9.27, amt=168998,yld=7.60,pay=52.1,ocfd=2.81),
 dict(mkt='深',name='云南白药',sym='000538.SZ',ind='医药',vol=13.78,mdd=-16.13,amt=48753, yld=4.15,pay=61.8,ocfd=1.43),
 dict(mkt='深',name='双汇发展',sym='000895.SZ',ind='食品',vol=18.65,mdd=-21.12,amt=30383, yld=5.84,pay=98.6,ocfd=1.28),
]
p=pd.DataFrame(port)
p['score']=1/np.sqrt(p.vol*p.mdd.abs())
for m in ['沪','深']:
    k=p.mkt==m; p.loc[k,'wm']=(p.loc[k,'score']/p.loc[k,'score'].sum()*100).round(1)
p['wt']=(p.wm*0.5).round(1)
p.to_csv('打新底仓_最终8只组合.csv',index=False,encoding='utf-8-sig')

sh=p[p.mkt=='沪']; sz=p[p.mkt=='深']
vol_sh=np.average(sh.vol,weights=sh.wm); vol_sz=np.average(sz.vol,weights=sz.wm)
yld_all=np.average(p.yld,weights=p.wt); mdd_all=np.average(p.mdd.abs(),weights=p.wt)

rows=[]
for _,r in p.iterrows():
    flag=''
    if r.name=='双汇发展': flag='<span class="warn">支付率贴线</span>'
    if r.mkt=='深': flag+='<span class="tagd">子池</span>'
    rows.append(f"""<tr>
<td class="mk {r.mkt}">{r.mkt}</td>
<td class="nm"><b>{r.name}</b><small>{r.sym}</small></td>
<td>{r.ind}</td>
<td class="num g">{r.vol:.2f}%</td>
<td class="num g">{r.mdd:.2f}%</td>
<td class="num">{r.amt:,.0f}</td>
<td class="num y">{r.yld:.2f}%</td>
<td class="num">{r.pay:.1f}%</td>
<td class="num">{r.ocfd:.2f}</td>
<td class="num strong">{r.wm:.1f}%</td>
<td class="num strong">{r.wt:.1f}%</td>
<td>{flag}</td></tr>""")

# 深市核验表
chk=[('格力电器','000651.SZ',52.1,57.9,2.81,'入选'),
     ('云南白药','000538.SZ',61.8,90.5,1.43,'入选'),
     ('双汇发展','000895.SZ',98.6,99.4,1.28,'入选（贴线）'),
     ('平安银行','000001.SZ',27.9,30.0,12.64,'备选·支付率28%未达'),
     ('苏州银行','002966.SZ',31.2,32.5,8.22,'备选·资本趋势下行'),
     ('苏泊尔','002032.SZ',100.3,100.4,1.11,'剔除·支付率>100%')]
crows=[]
for n,s,pay,pmax,ocfd,res in chk:
    c='hit' if '入选' in res and '贴线' not in res else ('edge' if '入选' in res or '备选' in res else 'out')
    crows.append(f"""<tr class="{c}"><td class="nm"><b>{n}</b><small>{s}</small></td>
<td class="num">✓</td><td class="num {'g' if pmax<100 else 'r'}">{pmax:.1f}%</td>
<td class="num">{pay:.1f}%</td><td class="num {'g' if ocfd>1 else 'r'}">{ocfd:.2f}</td>
<td>{res}</td></tr>""")

html=f"""<!DOCTYPE html><html lang="zh-CN"><head><meta charset="utf-8"><title>打新底仓 · 沪深 8 只最终组合</title>
<style>
:root{{--bg:#0f1115;--card:#171a21;--card2:#1d2129;--line:#2a2f3a;--tx:#e6e8ec;--tx2:#9aa3b2;--tx3:#6b7381;
--red:#f0554d;--green:#2fb87a;--amber:#e8a33d;--blue:#4a90d9;}}
*{{box-sizing:border-box;margin:0;padding:0}}
body{{background:var(--bg);color:var(--tx);font:14px/1.6 -apple-system,"Segoe UI","PingFang SC","Microsoft YaHei",sans-serif;padding:32px 28px 64px}}
.wrap{{max-width:1240px;margin:0 auto}}
h1{{font-size:24px;font-weight:650;letter-spacing:-.3px;margin-bottom:6px}}
.sub{{color:var(--tx2);font-size:13px;margin-bottom:26px}} .sub b{{color:var(--tx)}}
.kpi{{display:grid;grid-template-columns:repeat(5,1fr);gap:12px;margin-bottom:8px}}
.k{{background:var(--card);border:1px solid var(--line);border-radius:10px;padding:14px 16px}}
.k .lab{{color:var(--tx3);font-size:11.5px;letter-spacing:.4px;margin-bottom:5px}}
.k .val{{font-size:21px;font-weight:650;font-variant-numeric:tabular-nums}}
.k .val small{{font-size:11.5px;font-weight:400;color:var(--tx2);margin-left:2px}}
.k.hi{{border-color:#2f5d46;background:linear-gradient(180deg,#17251e,#171a21)}}
.k.hi .val{{color:var(--green)}}
h2{{font-size:15px;font-weight:600;margin:30px 0 12px;padding-left:10px;border-left:3px solid var(--blue)}}
table{{width:100%;border-collapse:separate;border-spacing:0;background:var(--card);border:1px solid var(--line);border-radius:10px;overflow:hidden;font-size:12.5px}}
th{{background:var(--card2);color:var(--tx2);font-weight:500;font-size:11px;letter-spacing:.3px;text-align:left;padding:9px 11px;border-bottom:1px solid var(--line);white-space:nowrap}}
td{{padding:9px 11px;border-bottom:1px solid #21252e;vertical-align:middle}}
tr:last-child td{{border-bottom:none}}
tbody tr:hover{{background:#1a1e25}}
.mk{{text-align:center;font-weight:600;font-size:12px;width:28px}}
.mk.沪{{color:var(--blue)}} .mk.深{{color:#c084d8}}
.nm b{{font-weight:600;font-size:13px}} .nm small{{display:block;color:var(--tx3);font-size:10px;margin-top:1px}}
.num{{text-align:right;font-variant-numeric:tabular-nums;white-space:nowrap}}
.g{{color:var(--green)}} .r{{color:var(--red)}} .y{{color:var(--amber)}}
.strong{{font-weight:650;color:#fff}}
.warn{{display:inline-block;padding:1px 7px;border-radius:20px;font-size:10.5px;background:rgba(232,163,61,.14);color:var(--amber);border:1px solid rgba(232,163,61,.3);margin-left:2px}}
.tagd{{display:inline-block;padding:1px 7px;border-radius:20px;font-size:10.5px;background:rgba(155,109,214,.14);color:#c084d8;border:1px solid rgba(155,109,214,.3)}}
tr.hit{{background:rgba(47,184,122,.055)}} tr.edge{{background:rgba(232,163,61,.045)}} tr.out{{opacity:.4}}
.note{{background:var(--card);border:1px solid var(--line);border-left:3px solid var(--blue);border-radius:8px;padding:14px 18px;margin-top:16px;font-size:12.5px;color:var(--tx2)}}
.note b{{color:var(--tx)}} .note.warn2{{border-left-color:var(--amber)}} .note.dan{{border-left-color:var(--red)}} .note.ok2{{border-left-color:var(--green)}}
.split{{display:grid;grid-template-columns:1fr 1fr;gap:14px;margin-top:16px}}
.box{{background:var(--card);border:1px solid var(--line);border-radius:10px;padding:15px 18px}}
.box h3{{font-size:13px;font-weight:600;margin-bottom:9px;color:var(--tx)}}
.box ul{{list-style:none;font-size:12px;color:var(--tx2);line-height:1.85}}
.box li::before{{content:"·";color:var(--tx3);margin-right:7px;font-weight:700}}
.foot{{color:var(--tx3);font-size:11.5px;margin-top:34px;padding-top:16px;border-top:1px solid var(--line);line-height:1.8}}
code{{background:#22262f;padding:1px 5px;border-radius:4px;font-size:11.5px;color:#a8b4c8}}
</style></head><body><div class="wrap">
<h1>打新底仓 · 沪深 8 只最终组合</h1>
<div class="sub">沪市 5 只（11 条全过 + ⑫⑬⑭）· 深市 3 只（低波 + 流动性 + 股息率 + 三条分红底线）· 基准日 <b>2026-10-15</b></div>

<div class="kpi">
<div class="k hi"><div class="lab">组合标的</div><div class="val">8<small>只</small></div></div>
<div class="k"><div class="lab">沪 / 深</div><div class="val">5<small>/</small>3</div></div>
<div class="k"><div class="lab">组合加权股息率</div><div class="val">{yld_all:.2f}<small>%</small></div></div>
<div class="k"><div class="lab">沪 / 深 加权波动</div><div class="val">{vol_sh:.1f}<small>/</small>{vol_sz:.1f}<small>%</small></div></div>
<div class="k"><div class="lab">加权最大回撤</div><div class="val">{mdd_all:.1f}<small>%</small></div></div>
</div>

<h2>组合明细（按市场内权重降序）</h2>
<table><thead><tr><th>市</th><th>标的</th><th>行业</th><th class="num">年化波动</th><th class="num">近1年回撤</th>
<th class="num">日均成交(万)</th><th class="num">股息率</th><th class="num">三年支付率</th><th class="num">OCF/分红</th>
<th class="num">市场内权重</th><th class="num">组合权重</th><th>备注</th></tr></thead><tbody>
{''.join(rows)}</tbody></table>

<h2>深市子池 · 三条分红底线核验（2023–2025）</h2>
<table><thead><tr><th>标的</th><th class="num">①连续分红</th><th class="num">②单年最高支付率</th>
<th class="num">③三年累计支付率</th><th class="num">三年 OCF/分红</th><th>判定</th></tr></thead><tbody>
{''.join(crows)}</tbody></table>

<div class="note ok2"><b>格力电器的支付率疑虑可以打消</b>：2023/2024/2025 支付率 46.2% → 52.2% → 57.9%，三年累计 52.1%，最高仅 57.9%，远低于 100%。OCF/分红 4.21 / 1.75 / 2.76，三年合计 2.81。支付率逐年小幅提升是良性的分红增长，不是透支。7.60% 的股息率有真实现金流支撑。</div>

<div class="note warn2"><b>双汇发展是八只里安全边际最薄的一只</b>：支付率连续四年贴着 98–99%（2022 98.6% / 2023 99.4% / 2024 97.9% / 2025 98.4%），2023 年 OCF/分红仅 <b>0.67</b>（经营现金流 33.9 亿 < 分红 50.2 亿）。它通过底线是因为「高位稳定」而非「宽裕」——本质是零再投资的全额分配模式。建议权重压到深市子池最低（25.1%），并纳入年度复核。</div>

<div class="note"><b>苏泊尔被三条底线挡下</b>：支付率 2023/2024/2025 分别为 100.4% / 100.3% / 100.3%，三年累计 100.3%，超过 100% 上限。它波动率仅 21.35%、股息率 6.60%，但分红超过净利润，属于典型透支式分配。这验证了支付率上限这条底线的必要性。</div>

<div class="split">
<div class="box"><h3>平安银行：资本达标，但分红比例不足</h3><ul>
<li>核心一级 <b>9.32%</b>（2026中报）≥ 9.0% 门槛 ✓</li>
<li>不良率 1.05%，拨备 219.58% ✓</li>
<li>支付率 2023 30.0% → 2024 26.5% → 2025 27.1%，<b>低于 28% 且 2024 年下修</b></li>
<li>判定：备选。若你愿意为深市银行放宽「支付率 ≥28%」，可替换双汇</li></ul></div>
<div class="box"><h3>苏州银行：资本刚好过线，但趋势向下</h3><ul>
<li>核心一级 9.16%（2026中报）≥ 9.0% ✓</li>
<li><b>但 2026Q1 曾降至 8.97%，跌破 9.0%</b></li>
<li>趋势：9.77%（2024）→ 9.53%（2025）→ 9.16%（2026H1），持续下行</li>
<li>判定：备选。仅在你接受 9.0% 门槛且容忍下行趋势时纳入</li></ul></div>
</div>

<h2>羚锐制药：移出打新底仓</h2>
<div class="note dan">
<b>移出理由</b>：近半年年化波动 <b>26.98%</b>（近一年 23.29%，抬升 3.69pct，是 6 只里升幅最大）；2026-08-12 单日跌 <b>9.22%</b>（近一年唯一一次单日跌幅 >7%）；且是 6 只中唯一非金融/非公用事业标的。<br><br>
<b>处理方式</b>：保留在红利核心池作长期持有，<b>不用于打新市值计算</b>。<br><br>
<b>回补条件</b>（需同时满足）：① 近半年年化波动回落至 25% 以下；② 无单日跌幅 >7% 记录；③ 下一期定期复核时 ⑫⑬⑭ 三项齐过。满足后可重新纳入候选，但回补后需观察一个季度再配满权重。
</div>

<h2>权重方法</h2>
<div class="note">
采用<b>波动率与回撤的几何倒数</b>：<code>score = 1 / √(年化波动率 × |最大回撤|)</code>，市场内归一化后，沪深各占 50%。<br>
这个口径同时惩罚高波动和大回撤，避免单纯用波动率倒数时把「低波但深跌」的标的权重抬高。若你的沪深打新额度需求不是 1:1，只需调整两市总额比例，市场内权重不变。<br><br>
结果上：格力（15.68% / −9.27%）拿到组合最高权重 20.7%，洪城环境（19.00% / −13.88%）在沪市最高 11.9%，农业银行因回撤 −28.87% 被压到最低 7.4%——符合「低波高权重」原则。
</div>

<h2>年度复核清单</h2>
<div class="note">
深市 3 只与沪市 5 只，每年年报披露后核一次：<br>
① <b>支付率</b>：连续两年 >100%（深市底线）或 >80%（沪市 11 条口径）→ 移出<br>
② <b>OCF/分红</b>：连续两年 <1 → 移出<br>
③ <b>年化波动率</b>：滚动 252 日突破 25%（或近半年突破 26%）→ 降权或移出<br>
④ <b>日均成交额</b>：63 日均值跌破 5000 万 → 移出（冲击成本失控）<br>
⑤ <b>银行专项</b>（沪农商、农行、及备选平安/苏州）：核心一级 ≥9.0%、不良率 ≤1.5%、拨备 ≥180%<br><br>
数据湖侧需要同步修的：<code>daily_bars_adj.qfq_close</code> 与 <code>close</code> 完全相等，前复权未生效。本轮已用 <code>corporate_actions</code> 重建（见 <code>qfq_returns_rebuilt.parquet</code>），但应推动上游修复，否则每次复算都要手工补。
</div>

<div class="foot">
数据源：cnequity 数据湖（financial_statement_items / corporate_actions / daily_bars）· 分红东财 RPT_SHAREBONUS_DET（报告期口径）· 银行指标东财 RPT_F10_FINANCE_MAINFINADATA<br>
波动 = 252 日复权日收益率标准差 × √252；回撤 = 窗口内复权净值最大回撤；成交额 = 63 日算术均值。仅供研究，不构成投资建议。
</div>
</div></body></html>"""
open('打新底仓_最终组合.html','w',encoding='utf-8').write(html)
print("已生成 打新底仓_最终组合.html")
print(f"\n沪加权波动 {vol_sh:.2f}%  深加权波动 {vol_sz:.2f}%  组合股息率 {yld_all:.2f}%  加权回撤 {mdd_all:.2f}%")
