# -*- coding: utf-8 -*-
"""
在 11 条高股息标准之上，叠加打新底仓专用的三条正交约束：
  (12) 年化波动率 < 25%      —— 过去252个交易日 qfq 日收益率标准差 × sqrt(252)
  (13) 近3个月日均成交额 >= 5000万元 —— 约63个交易日，普通成交额口径
  (14) 当前股息率 < 近3年均值 × 2    —— 剔除突击分红/财务粉饰
基准日：2026-10-15（10-16 数据不完整，已剔除）
"""
import duckdb, pandas as pd, numpy as np, math

BASE = '2026-10-15'
ANN  = math.sqrt(252)
VOL_MAX   = 25.0      # %
AMT_MIN   = 5000.0    # 万元
N_VOL     = 252       # 波动率窗口（交易日）
N_AMT     = 63        # 流动性窗口（交易日≈3个月）

con = duckdb.connect(':memory:')
con.execute("ATTACH 'D:/repository/数据湖/data/cnequity/duckdb/cnequity.duckdb' AS src (read_only)")

pool = pd.read_csv('最终核心池_银行核验后.csv', encoding='utf-8-sig')
pool = pool[pool['结论'].isin(['保留','降级'])].copy()
extra = pd.DataFrame([
    {'symbol':'002170.SZ','name':'芭田股份'},
    {'symbol':'600325.SH','name':'华发股份'},
])
# 用户点名的对照标的（若已在池中则跳过）
for s,n in [('002170.SZ','芭田股份')]:
    if s not in set(pool.symbol): pool = pd.concat([pool, pd.DataFrame([{'symbol':s,'name':n,'结论':'对照'}])])
syms = pool['symbol'].tolist()

print(f"池内标的 {len(syms)} 只 -> {pool['name'].tolist()}\n")

# ---------- (12) 年化波动率 ----------
px = con.execute(f"""
select symbol, trade_date, qfq_close
from src.daily_bars_adj
where symbol in ({','.join("'"+s+"'" for s in syms)})
  and trade_date <= DATE '{BASE}' and qfq_close is not null and qfq_close > 0
order by symbol, trade_date
""").df()
px['ret'] = px.groupby('symbol')['qfq_close'].pct_change()

vol_rows = []
for s, g in px.groupby('symbol'):
    g = g.dropna(subset=['ret']).tail(N_VOL)
    r = g['ret'].values
    vol_rows.append({'symbol':s, 'vol_n':len(r),
                     'vol_ann': round(float(np.std(r, ddof=1))*ANN*100, 2),
                     'vol_window': f"{g['trade_date'].min()}~{g['trade_date'].max()}",
                     'max_dd_1y': round(float((g['qfq_close']/g['qfq_close'].cummax()-1).min())*100, 2)})
vol = pd.DataFrame(vol_rows)

# ---------- (13) 近3个月日均成交额 ----------
amt = con.execute(f"""
with d as (
  select symbol, trade_date, amount,
         row_number() over (partition by symbol order by trade_date desc) rk
  from src.daily_bars
  where symbol in ({','.join("'"+s+"'" for s in syms)})
    and trade_date <= DATE '{BASE}' and amount is not null
)
select symbol, count(*) n, avg(amount)/1e4 amt_wan, median(amount)/1e4 amt_med_wan
from d where rk <= {N_AMT} group by 1
""").df()

d = pool[['symbol','name','is_bank','is_util','industry_name','结论','yld_ttm','yld3','dps_ttm','px']].copy()
d = d.merge(vol, on='symbol', how='left').merge(amt, on='symbol', how='left')

# ---------- (14) 股息率异常 ----------
d['yld_ratio'] = (d['yld_ttm']/d['yld3']).round(2)

d['c12'] = d['vol_ann'] < VOL_MAX
d['c13'] = d['amt_wan'] >= AMT_MIN
d['c14'] = d['yld_ratio'] < 2.0
d['n3pass'] = d[['c12','c13','c14']].sum(axis=1)
d['底仓适配'] = np.where(d['n3pass']==3, '适配', np.where(d['c13']==False,'流动性不足','波动/股息异常'))

pd.set_option('display.width', 300); pd.set_option('display.max_columns', 60); pd.set_option('display.max_rows', 100)
out = d[['symbol','name','industry_name','结论','vol_ann','max_dd_1y','amt_wan','yld_ttm','yld3','yld_ratio','c12','c13','c14','n3pass','底仓适配']].sort_values('vol_ann')
out.columns = ['代码','名称','行业','排雷结论','年化波动率%','近1年最大回撤%','日均成交额(万)','当前股息率%','近3年均值%','倍数','⑫','⑬','⑭','通过','底仓适配']
print(out.to_string(index=False))

d.to_csv('打新底仓_低波流动性复算.csv', index=False, encoding='utf-8-sig')
print("\n已导出 打新底仓_低波流动性复算.csv")
