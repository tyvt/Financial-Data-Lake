"""银行专项核验报表（中泰红利三维框架：资本/质量/盈利）。"""
import pandas as pd, html

b = pd.read_csv('D:/repository/数据湖/分析产出/银行专项核验.csv')
b = b.sort_values('cet1', ascending=False)

def tag(v):
    c = {'通过': 'ok', '不达标': 'warn', '剔除': 'bad'}[v]
    return f'<span class="tag {c}">{v}</span>'

def bar(v, base=7.5, full=15):
    pct = max(0, min(100, (v - base) / (full - base) * 100))
    return f'<div class="bar"><i style="width:{pct:.0f}%"></i></div>'

rows = []
for _, r in b.iterrows():
    cushion = r.cet1 - 7.5
    nim = str(r.nim).split('/')
    rows.append(f"""<tr>
<td class="code">{r.symbol}</td><td class="name">{html.escape(str(r['name']))}</td>
<td class="num hi">{r.yld_ttm:.2f}%</td>
<td class="num big">{r.cet1:.2f}%{bar(r.cet1)}<div class="yr">安全垫 +{cushion:.2f}pp</div></td>
<td class="num">{r.car:.2f}%</td>
<td class="num">{r.npl:.2f}%</td>
<td class="num">{r.cover:.0f}%</td>
<td class="num"><div class="avg">{nim[-1]}</div><div class="yr">{' / '.join(nim)}</div></td>
<td class="num"><div class="avg">{r.payout3:.1f}%</div><div class="yr">{r.p23:.1f} / {r.p24:.1f} / {r.p25:.1f}</div></td>
<td class="num">{r.roe3:.2f}%</td>
<td class="num">{tag(r['结论'])}</td></tr>""")

doc = f"""<!DOCTYPE html><html lang="zh-CN"><head><meta charset="utf-8">
<title>银行股专项核验</title>
<style>
*{{box-sizing:border-box}}
body{{margin:0;padding:32px 28px 48px;background:#0d1117;color:#e6edf3;
 font-family:-apple-system,"Segoe UI","Microsoft YaHei",sans-serif}}
h1{{font-size:22px;margin:0 0 6px;font-weight:600}}
.meta{{color:#8b949e;font-size:12.5px;line-height:1.8;margin-bottom:22px}}
.meta b{{color:#c9d1d9}}
table{{width:100%;border-collapse:collapse;font-size:12.5px;font-variant-numeric:tabular-nums}}
thead th{{text-align:right;padding:9px 8px;border-bottom:1px solid #30363d;color:#8b949e;
 font-size:11px;font-weight:500;line-height:1.5;white-space:nowrap;vertical-align:bottom}}
thead th:nth-child(-n+2){{text-align:left}}
.sub{{display:block;color:#484f58;font-size:10px}}
tbody td{{padding:12px 8px;border-bottom:1px solid #161b22;text-align:right;white-space:nowrap;vertical-align:top}}
tbody td.code{{text-align:left;color:#8b949e;font-size:12px}}
tbody td.name{{text-align:left;font-weight:600;font-size:13px}}
tbody tr:hover{{background:#11161d}}
.hi{{color:#f0883e;font-weight:700}}
.big{{font-size:14px;font-weight:700}}
.avg{{font-weight:700}}
.yr{{color:#6e7681;font-size:10px;margin-top:3px;font-weight:400}}
.bar{{height:3px;background:#21262d;border-radius:2px;margin-top:5px;overflow:hidden}}
.bar i{{display:block;height:100%;background:linear-gradient(90deg,#1f6feb,#3fb950)}}
.tag{{font-size:10.5px;padding:2px 8px;border-radius:10px}}
.tag.ok{{background:#1f3a2a;color:#3fb950}}
.tag.warn{{background:#3a3218;color:#d29922}}
.tag.bad{{background:#3a1f1f;color:#f85149}}
.note{{margin-top:24px;font-size:11.5px;color:#6e7681;line-height:1.95;max-width:1180px}}
.note b{{color:#8b949e}}
.veto{{margin-top:18px;border:1px solid #21262d;border-radius:8px;padding:14px 18px;background:#11161d;font-size:12px;color:#8b949e;line-height:1.9;max-width:1180px}}
.veto b{{color:#c9d1d9}}
</style></head><body>
<h1>银行股专项核验 · 红利三维框架</h1>
<div class="meta">资本（能不能分）→ 质量（分得安不安全）→ 盈利（分得持不持久）　·　数据：2026 中报　·　第 4 列为核心一级资本充足率，条形以 7.5% 监管底线起算</div>
<table><thead><tr>
<th>代码</th><th>名称</th><th>股息率<span class="sub">TTM</span></th>
<th>核心一级资本<span class="sub">≥9.5%</span></th><th>资本充足率</th>
<th>不良率<span class="sub">≤1.5%</span></th><th>拨备覆盖率<span class="sub">≥180%</span></th>
<th>净息差<span class="sub">23/24/25 年报</span></th><th>分红比例<span class="sub">23/24/25</span></th>
<th>ROE 3年均</th><th>结论</th>
</tr></thead><tbody>{''.join(rows)}</tbody></table>
<div class="veto">
<b>一票否决检查结果</b><br>
· 核心一级资本低于监管底线（7.5%+附加）：<b>无</b>，最低为江苏银行 8.67%<br>
· 拨备覆盖率 &lt; 150%：<b>无</b>，最低为农业银行 290%<br>
· 近 3 年分红比例趋势性下修：<b>无</b>，南京银行 31.95→29.81→30.07 属单年回落再回升，不构成趋势<br>
· 不良率 &gt; 1.8% 且拨备 &lt; 150%：<b>无</b>
</div>
<div class="note">
<b>结论</b>：6 家中 3 家通过（沪农商行 13.65%、渝农商行 12.33%、农业银行 10.80%），
3 家未达 9.5% 门槛：南京银行 9.37%（差 0.13pp）、苏州银行 9.16%（差 0.34pp）、江苏银行 8.67%（差 0.83pp）。<br>
<b>为何卡在资本而非股息</b>：江苏银行股息率 4.59%、ROE 13.75% 均为 6 家最优，但核心一级仅 8.67%，
一旦信贷扩张或分红比例继续提升，资本补充压力会先于股息见顶；这是典型的"高股息但分红空间受限"。<br>
<b>净息差</b>：6 家 2023→2025 全部收窄，渝农商行（1.73→1.60→1.66）与苏州银行（1.68→1.33→1.40）已现企稳回升，
沪农商行 1.67→1.37 降幅最大，农行 1.28 处低位企稳。<br>
<b>拨备</b>：全部 &gt;290%，无"贴地飞行"；苏州银行 382% 最高，属利润留存偏多，分红比例仍有提升余地。
</div></body></html>"""
open('D:/repository/数据湖/分析产出/银行专项核验.html', 'w', encoding='utf-8').write(doc)

# 更新最终清单
keep = pd.read_csv('D:/repository/数据湖/分析产出/排雷_2026H1_结论.csv')
drop = set(b[b['结论'] != '通过'].symbol)
core = keep[(keep['结论'] == '保留') & (~keep.symbol.isin(drop))].sort_values('yld_ttm', ascending=False)
core.to_csv('D:/repository/数据湖/分析产出/最终核心池_银行核验后.csv', index=False, encoding='utf-8-sig')
print('core', len(core), list(core.name))
