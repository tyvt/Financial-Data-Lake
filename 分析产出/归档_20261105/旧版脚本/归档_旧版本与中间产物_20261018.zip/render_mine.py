"""2026 半年报排雷：利润与经营现金流同比，输出保留/降级/剔除。"""
import pandas as pd, html

m = pd.read_csv('D:/repository/数据湖/分析产出/排雷_2026H1.csv')

def verdict(r):
    if pd.isna(r.np_yoy):
        return '数据缺失'
    if r.np_yoy <= -10:
        return '剔除'
    if r.ocf_h1 < 0 and (r.ocf_h1_ly >= 0 or r.ocf_chg <= -15):
        return '剔除'
    if r.is_bank == 1:
        return '保留'
    if (r.np_yoy < 0 and r.ocf_yoy <= 0) or r.ocf_yoy <= -30:
        return '降级'
    return '保留'

m['结论'] = m.apply(verdict, axis=1)
order = {'剔除': 0, '降级': 1, '保留': 2, '数据缺失': 3}
m = m.sort_values(['结论', 'yld_ttm'], key=lambda s: s.map(order) if s.name == '结论' else s,
                  ascending=[True, False])
m.to_csv('D:/repository/数据湖/分析产出/排雷_2026H1_结论.csv', index=False, encoding='utf-8-sig')

def pct(v, rev=True):
    if pd.isna(v):
        return '—'
    cls = ('up' if v >= 0 else 'down') if rev else ('down' if v >= 0 else 'up')
    return f'<span class="{cls}">{v:+.1f}%</span>'

rows = []
for _, r in m.iterrows():
    tag = {'剔除': 'bad', '降级': 'warn', '保留': 'ok', '数据缺失': 'na'}[r['结论']]
    bank = ' <span class="bk">银行</span>' if r.is_bank == 1 else ''
    ocf_cls = 'up' if r.ocf_chg >= 0 else 'down'
    rows.append(f"""<tr>
<td class="code">{r.symbol}</td><td class="name">{html.escape(str(r['name']))}{bank}</td>
<td class="ind">{html.escape(str(r.industry_name))}</td>
<td class="num hi">{r.yld_ttm:.2f}%</td>
<td class="num">{r.np_h1_ly:,.1f} → <b>{r.np_h1:,.1f}</b></td>
<td class="num">{pct(r.np_yoy)}</td>
<td class="num">{pct(r.rev_yoy26)}</td>
<td class="num">{r.ocf_h1_ly:,.1f} → <b>{r.ocf_h1:,.1f}</b></td>
<td class="num"><span class="{ocf_cls}">{r.ocf_chg:+,.1f}亿</span></td>
<td class="num"><span class="tag {tag}">{r['结论']}</span></td></tr>""")

cnt = m['结论'].value_counts().to_dict()
doc = f"""<!DOCTYPE html><html lang="zh-CN"><head><meta charset="utf-8">
<title>2026 半年报排雷 · 23 只高股息标的</title>
<style>
*{{box-sizing:border-box}}
body{{margin:0;padding:32px 28px 48px;background:#0d1117;color:#e6edf3;
 font-family:-apple-system,"Segoe UI","Microsoft YaHei",sans-serif}}
h1{{font-size:22px;margin:0 0 6px;font-weight:600}}
.meta{{color:#8b949e;font-size:12.5px;line-height:1.8;margin-bottom:18px}}
.meta b{{color:#c9d1d9}}
.sum{{display:flex;gap:8px;list-style:none;padding:0;margin:0 0 22px}}
.sum li{{background:#161b22;border:1px solid #21262d;border-radius:6px;padding:8px 14px;font-size:12px;color:#8b949e}}
.sum li b{{font-size:16px;margin-left:6px}}
.b-bad{{color:#f85149}} .b-warn{{color:#d29922}} .b-ok{{color:#3fb950}}
table{{width:100%;border-collapse:collapse;font-size:12.5px;font-variant-numeric:tabular-nums}}
thead th{{text-align:right;padding:8px 7px;border-bottom:1px solid #30363d;color:#8b949e;
 font-size:11px;font-weight:500;white-space:nowrap;vertical-align:bottom;line-height:1.5}}
thead th:nth-child(-n+3){{text-align:left}}
.sub{{display:block;color:#484f58;font-size:10px}}
tbody td{{padding:10px 7px;border-bottom:1px solid #161b22;text-align:right;white-space:nowrap}}
tbody td.code{{text-align:left;color:#8b949e;font-size:12px}}
tbody td.name{{text-align:left;font-weight:600;font-size:13px}}
tbody td.ind{{text-align:left;color:#6e7681;font-size:11px}}
tbody tr:hover{{background:#11161d}}
.hi{{color:#f0883e;font-weight:700}}
.up{{color:#f85149;font-weight:600}}
.down{{color:#3fb950;font-weight:600}}
.bk{{font-size:9px;color:#8b949e;border:1px solid #30363d;border-radius:3px;padding:0 3px;margin-left:2px}}
.tag{{font-size:10.5px;padding:2px 8px;border-radius:10px;white-space:nowrap}}
.tag.ok{{background:#1f3a2a;color:#3fb950}}
.tag.warn{{background:#3a3218;color:#d29922}}
.tag.bad{{background:#3a1f1f;color:#f85149}}
.tag.na{{background:#21262d;color:#8b949e}}
.note{{margin-top:22px;font-size:11.5px;color:#6e7681;line-height:1.9;max-width:1180px}}
.note b{{color:#8b949e}}
</style></head><body>
<h1>2026 半年报排雷 · 23 只高股息标的</h1>
<div class="meta">口径：2026 中报 vs 2025 中报（合并报表，累计值）　·　金额单位 <b>亿元</b>　·　按结论分组，组内按股息率 TTM 降序<br>
判定：利润同比 ≤ −10% 或 经营现金流转负 → <b>剔除</b>；利润下滑且现金流未改善，或现金流降幅 &gt; 30% → <b>降级</b></div>
<ul class="sum">
<li>剔除<b class="b-bad">{cnt.get('剔除',0)}</b></li>
<li>降级<b class="b-warn">{cnt.get('降级',0)}</b></li>
<li>保留<b class="b-ok">{cnt.get('保留',0)}</b></li>
</ul>
<table><thead><tr>
<th>代码</th><th>名称</th><th>行业</th><th>股息率<span class="sub">TTM</span></th>
<th>归母净利<span class="sub">2025H1 → 2026H1（亿元）</span></th><th>净利同比</th><th>营收同比</th>
<th>经营现金流<span class="sub">2025H1 → 2026H1（亿元）</span></th><th>现金流变动</th><th>结论</th>
</tr></thead><tbody>{''.join(rows)}</tbody></table>
<div class="note">
<b>与你点名的对照</b>：申能 −19.0%、海尔 −14.3%、海油发展现金流由 −4.8 转为 −25.0 亿（同比 −20.2 亿）—— 三只均在 23 只名单内，已判剔除。
华润三九 −8.0%（2026H1 归母 16.7 亿，现金流 24.2 亿），但它本就没通过 ②（3 年均股息率 3.22%），不在这 23 只里，无需再排。<br>
<b>你判定可保留的 5 只</b>：羚锐制药（现金流 +3.7 亿 / +103%）、洪城环境（+2.3 亿 / +65%）、佛燃能源（+6.6 亿 / +97%）、唐山港（+2.3 亿 / +25%）、陕西能源（+5.9 亿 / +15%）—— 全部核验为现金流改善，结论保留。<br>
<b>银行处理</b>：农业银行、江苏银行、南京银行经营现金流同比大幅下滑（−71% / −40% / −12%），但银行 OCF 含同业往来与拆借，波动属科目特性，
不作为排雷依据，统一按利润表现判定。三家利润同比分别 +4.9% / +8.1% / +8.2%，均保留。<br>
<b>降级处理</b>：隆鑫通用、菜百股份为利润小幅下滑且现金流同步走弱；海信视像、纽威股份为利润增长但现金流降幅超 30%，保留在观察区，不加仓。
</div></body></html>"""
open('D:/repository/数据湖/分析产出/排雷_2026H1.html', 'w', encoding='utf-8').write(doc)
print(cnt, len(m))
print(m[['symbol','name','结论']].to_string())
