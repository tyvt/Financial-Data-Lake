import duckdb, pandas as pd
con = duckdb.connect(':memory:')
con.execute("ATTACH 'D:/repository/数据湖/data/cnequity/duckdb/cnequity.duckdb' AS src (read_only)")
codes = [r[0] for r in con.execute("select distinct item_code from src.financial_statement_items where symbol='002170.SZ' order by 1").fetchall()]
print(len(codes)); print(codes)
