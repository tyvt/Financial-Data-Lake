# -*- coding: utf-8 -*-
"""最终组合：沪5 + 深3，8 只打新底仓"""
import duckdb, pandas as pd, numpy as np
pd.set_option('display.width',320); pd.set_option('display.max_columns',50)
con=duckdb.connect(':memory:')
con.execute("ATTACH 'D:/repository/数据湖/data/cnequity/duckdb/cnequity.duckdb' AS src (read_only)")

# 羚锐制药 大跌日核查（近1年 |r|>7%）
r=pd.read_parquet('qfq_returns_rebuilt.parquet')
lr=r[r.symbol=='600285.SH'].copy()
lr['d']=pd.to_datetime(lr.trade_date)
big=lr[(lr.r_adj.abs()>0.07)&(lr.d>=pd.Timestamp('2026-01-01'))]
print("=== 羚锐制药 近一年单日 |涨跌|>7% ===")
print(big[['d','r_adj']].assign(pct=(big.r_adj*100).round(2))[['d','pct']].to_string(index=False))

# 近半年波动（126日）
lr126=lr['r_adj'].dropna().tail(126)
print(f"\n羚锐 近半年年化波动 {float(np.std(lr126,ddof=1))*np.sqrt(252)*100:.2f}%  近一年 {float(np.std(lr['r_adj'].dropna().tail(252),ddof=1))*np.sqrt(252)*100:.2f}%")

# ---------- 组合权重 ----------
port=pd.DataFrame([
 # 沪市
 dict(sym='600461.SH',name='洪城环境',mkt='沪',ind='环保',vol=19.00,mdd=-13.88,amt=10502,yld=5.19,pay3=63.4,ocfd=2.06),
 dict(sym='601298.SH',name='青岛港',  mkt='沪',ind='交运',vol=20.90,mdd=-18.39,amt=10742,yld=3.50,pay3=None,ocfd=None),
 dict(sym='601825.SH',name='沪农商行',mkt='沪',ind='银行',vol=21.30,mdd=-19.56,amt=22663,yld=5.03,pay3=None,ocfd=None),
 dict(sym='601000.SH',name='唐山港',  mkt='沪',ind='交运',vol=22.18,mdd=-13.02,amt=20550,yld=4.22,pay3=None,ocfd=None),
 dict(sym='601288.SH',name='农业银行',mkt='沪',ind='银行',vol=23.62,mdd=-28.87,amt=260680,yld=3.45,pay3=None,ocfd=None),
 # 深市
 dict(sym='000651.SZ',name='格力电器',mkt='深',ind='家电',vol=15.68,mdd=-9.27, amt=168998,yld=7.60,pay3=52.1,ocfd=2.81),
 dict(sym='000538.SZ',name='云南白药',mkt='深',ind='医药',vol=13.78,mdd=-16.13,amt=48753, yld=4.15,pay3=61.8,ocfd=1.43),
 dict(sym='000895.SZ',name='双汇发展',mkt='深',ind='食品',vol=18.65,mdd=-21.12,amt=30383, yld=5.84,pay3=98.6,ocfd=1.28),
])
port['score']=1/np.sqrt(port.vol*port.mdd.abs())
for m in ['沪','深']:
    mask=port.mkt==m
    port.loc[mask,'w_mkt']=(port.loc[mask,'score']/port.loc[mask,'score'].sum()*100).round(1)
port['w_total']=(port.w_mkt*0.5).round(1)   # 沪深各 50%

print("\n=== 最终 8 只组合 ===")
o=port[['mkt','name','sym','ind','vol','mdd','amt','yld','pay3','ocfd','w_mkt','w_total']]
o.columns=['市','名称','代码','行业','年化波动%','近1年回撤%','日均成交(万)','股息率%','三年支付率%','OCF/分红','市场内权重%','组合权重%']
print(o.to_string(index=False))

# 组合层面指标
fmt=lambda x: x
w=port.w_total/100
cvol=float(np.sqrt(np.sum((w*port.vol)**2)))  # 粗略（假设不相关）
print(f"\n沪市 {len(port[port.mkt=='沪'])} 只  加权波动 {np.average(port[port.mkt=='沪'].vol,weights=port[port.mkt=='沪'].w_mkt):.2f}%")
print(f"深市 {len(port[port.mkt=='深'])} 只  加权波动 {np.average(port[port.mkt=='深'].vol,weights=port[port.mkt=='深'].w_mkt):.2f}%")
print(f"组合加权股息率 {np.average(port.yld,weights=port.w_total):.2f}%")
print(f"组合加权回撤 {np.average(port.mdd.abs(),weights=port.w_total):.2f}%")
port.to_csv('打新底仓_最终8只组合.csv',index=False,encoding='utf-8-sig')
