# -*- coding: utf-8 -*-
"""
重建前复权收益率序列（数据湖 qfq_close 未生效，与 close 完全等同）。
公式（标准前复权）：
  除权日 T: r_T = close_T / [(close_{T-1} - 每股现金红利)/(1+每股送股+每股转增)] - 1
  其余日期: r_T = close_T / close_{T-1} - 1
"""
import duckdb, pandas as pd, numpy as np

BASE='2026-10-15'
con=duckdb.connect(':memory:')
con.execute("ATTACH 'D:/repository/数据湖/data/cnequity/duckdb/cnequity.duckdb' AS src (read_only)")

pool=pd.read_csv('最终核心池_银行核验后.csv',encoding='utf-8-sig')
pool=pool[pool['结论'].isin(['保留','降级'])][['symbol','name','结论']]
syms=pool.symbol.tolist(); q=",".join("'"+s+"'" for s in syms)

px=con.execute(f"""select symbol,trade_date,close from src.daily_bars
 where symbol in ({q}) and trade_date<=DATE '{BASE}' and close>0 order by symbol,trade_date""").df()

ca=con.execute(f"""select symbol, cast(ex_date as date) ex_date,
   coalesce(cash_dividend,0) cash, coalesce(bonus_ratio,0) bonus,
   coalesce(transfer_ratio,0) transfer, coalesce(split_factor,1) split
 from src.corporate_actions
 where symbol in ({q}) and cast(ex_date as date)<=DATE '{BASE}'
   and cast(ex_date as date)>=DATE '2024-01-01'""").df()

print(f"除权事件 {len(ca)} 条，覆盖 {ca.symbol.nunique()} 只\n")

rec=[]
miss=[]
for s,g in px.groupby('symbol'):
    g=g.sort_values('trade_date').reset_index(drop=True)
    g['c_prev']=g['close'].shift(1)
    g['r_raw']=g['close']/g['c_prev']-1
    # 合并除权因子
    c_s=ca[ca.symbol==s]
    g=g.merge(c_s[['ex_date','cash','bonus','transfer']], left_on='trade_date', right_on='ex_date', how='left')
    g['has_ex']=g['ex_date'].notna()
    ratio=1+g['bonus'].fillna(0)+g['transfer'].fillna(0)
    prev_adj=(g['c_prev']-g['cash'].fillna(0))/ratio
    g['r_adj']=np.where(g['has_ex'], g['close']/prev_adj-1, g['r_raw'])
    # 校验：漏记除权的异常日（|原始收益|>7% 且无除权记录）
    bad=g[(g['r_raw'].abs()>0.07)&(~g['has_ex'])]
    if len(bad): miss.append((s,bad['trade_date'].dt.strftime('%Y-%m-%d').tolist(),bad['r_raw'].round(4).tolist()))
    rec.append(g[['symbol','trade_date','close','r_raw','r_adj','has_ex']])

allr=pd.concat(rec,ignore_index=True)
allr.to_parquet('qfq_returns_rebuilt.parquet',index=False)

print("=== 可能漏记除权的异常日（|原始收益|>7% 且无除权记录）===")
if miss:
    for s,ds,rs in miss: print(f"  {s}: {list(zip(ds,rs))}")
else: print("  无 —— 除权记录覆盖率完整")

print("\n=== 波动率：原始 qfq（错误） vs 重建复权（正确）===")
ANN=np.sqrt(252); out=[]
for s,g in allr.groupby('symbol'):
    for tag,col in [('raw','r_raw'),('adj','r_adj')]:
        r=g[col].dropna().tail(252)
        out.append({'symbol':s,'kind':tag,'vol':round(float(np.std(r,ddof=1))*ANN*100,2),'n':len(r)})
o=pd.DataFrame(out).pivot(index='symbol',columns='kind',values='vol').reset_index()
n=pd.DataFrame(out).groupby('symbol')['n'].max().reset_index()
o=o.merge(n,on='symbol').merge(pool,on='symbol')
o['虚增']=(o['raw']-o['adj']).round(2)
o=o[['symbol','name','raw','adj','虚增','n']].sort_values('adj')
o.columns=['代码','名称','原qfq%','重建%','虚增pct','样本数']
pd.set_option('display.width',200)
print(o.to_string(index=False))
o.to_csv('波动率_复权修正对比.csv',index=False,encoding='utf-8-sig')
