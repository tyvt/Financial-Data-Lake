"""高股息 11 条件筛选（基于 cnequity 数据湖）。

口径说明：
- 每股现金分红：corporate_actions.cash_dividend（税前，元/股），按 ex_date 所在自然年归集，
  同一年内多次分红（中期+年度）累加。
- 年末收盘价：各年最后一个交易日 daily_bars.close（未复权）。
- 归母净利润：financial_statement_items.net_profit；ROE：roe（加权）；EPS：eps（基本）；
  每股经营现金流：ocf_per_share。
- 分红总额：dps × share_structure 中除权日前最近一期 total_shares。
"""
import duckdb

DB = 'D:/repository/数据湖/data/cnequity/duckdb/cnequity.duckdb'
con = duckdb.connect(DB, read_only=True)
con.execute("PRAGMA threads=4")
q = lambda s: con.sql(s).df()

con.execute("""
create or replace temp view dps as
select symbol, year(ex_date) y, sum(cash_dividend) dps
from corporate_actions
where action_type='cash_dividend' and cash_dividend is not null
  and ex_date between DATE '2023-01-01' and DATE '2025-12-31'
group by 1,2
""")

con.execute("""
create or replace temp view yclose as
with lastd as (select year(trade_date) y, max(trade_date) d from daily_bars
               where trade_date between DATE '2023-01-01' and DATE '2025-12-31' group by 1)
select b.symbol, lastd.y, b.close from daily_bars b join lastd on b.trade_date=lastd.d
""")

con.execute("""
create or replace temp view fin as
select symbol, report_period,
  max(case when item_code='net_profit' then item_value end) net_profit,
  max(case when item_code='net_profit_yoy' then item_value end) np_yoy,
  max(case when item_code='roe' then item_value end) roe,
  max(case when item_code='eps' then item_value end) eps,
  max(case when item_code='ocf_per_share' then item_value end) ocfps,
  max(case when item_code='total_assets' then item_value end) ta,
  max(case when item_code='total_liabilities' then item_value end) tl,
  max(case when item_code='net_cash_operate' then item_value end) ocf
from financial_statement_items
where report_period in ('2022Q4','2023Q4','2024Q4','2025Q4','2026Q2')
group by 1,2
""")

con.execute("""
create or replace temp view ret12 as
with p as (
  select symbol,
    max(case when trade_date=DATE '2025-10-09' then qfq_close end) p0,
    max(case when trade_date=DATE '2026-10-09' then qfq_close end) p1
  from daily_bars_adj
  where trade_date in (DATE '2025-10-09', DATE '2026-10-09') group by 1)
select symbol, (p1/p0-1)*100 ret12m from p where p0>0 and p1 is not null
""")

# 最新收盘价（2026-10-16）与 TTM 分红
con.execute("""
create or replace temp view latest as
with lastd as (select max(trade_date) d from daily_bars)
select b.symbol, b.close px from daily_bars b join lastd on b.trade_date=lastd.d
""")
con.execute("""
create or replace temp view dps_ttm as
select symbol, sum(cash_dividend) dps_ttm from corporate_actions
where action_type='cash_dividend' and ex_date > DATE '2025-10-09' and ex_date <= DATE '2026-10-09'
group by 1
""")

# 分红总额：dps × 除权日前后最近股本
con.execute("""
create or replace temp view div_total as
with ca as (
  select c.symbol, c.ex_date, c.cash_dividend, c.cash_dividend * s.total_shares amt
  from corporate_actions c
  asof left join share_structure s
    on c.symbol = s.symbol and c.ex_date >= s.change_date
  where c.action_type='cash_dividend' and c.cash_dividend is not null
    and c.ex_date between DATE '2023-01-01' and DATE '2025-12-31'
)
select symbol, sum(amt)/1e8 amt_yi from ca group by 1
""")

base = """
with b as (
  select i.symbol, i.name from instruments i
  where i.asset_type='stock' and i.list_date <= DATE '2022-01-01'
    and (i.delist_date is null or i.delist_date > DATE '2026-10-01')
),
a as (
  select b.symbol, b.name,
    d23.dps d23, d24.dps d24, d25.dps d25,
    c23.close c23, c24.close c24, c25.close c25,
    f22.net_profit np22, f23.net_profit np23, f24.net_profit np24, f25.net_profit np25,
    f23.np_yoy y23, f24.np_yoy y24, f25.np_yoy y25,
    f23.roe roe23, f24.roe roe24, f25.roe roe25,
    f23.eps eps23, f24.eps eps24, f25.eps eps25,
    f23.ocfps ocf23, f24.ocfps ocf24, f25.ocfps ocf25,
    f23.ocf cf23, f24.ocf cf24, f25.ocf cf25,
    f26.ta, f26.tl,
    r.ret12m, l.px, t.dps_ttm, dt.amt_yi
  from b
  left join dps d23 on d23.symbol=b.symbol and d23.y=2023
  left join dps d24 on d24.symbol=b.symbol and d24.y=2024
  left join dps d25 on d25.symbol=b.symbol and d25.y=2025
  left join yclose c23 on c23.symbol=b.symbol and c23.y=2023
  left join yclose c24 on c24.symbol=b.symbol and c24.y=2024
  left join yclose c25 on c25.symbol=b.symbol and c25.y=2025
  left join fin f22 on f22.symbol=b.symbol and f22.report_period='2022Q4'
  left join fin f23 on f23.symbol=b.symbol and f23.report_period='2023Q4'
  left join fin f24 on f24.symbol=b.symbol and f24.report_period='2024Q4'
  left join fin f25 on f25.symbol=b.symbol and f25.report_period='2025Q4'
  left join fin f26 on f26.symbol=b.symbol and f26.report_period='2026Q2'
  left join ret12 r on r.symbol=b.symbol
  left join latest l on l.symbol=b.symbol
  left join dps_ttm t on t.symbol=b.symbol
  left join div_total dt on dt.symbol=b.symbol
)
select a.*,
  case when d23>0 and d24>0 and d25>0 then 1 else 0 end c1,
  ( coalesce(d23/c23,0)+coalesce(d24/c24,0)+coalesce(d25/c25,0) )/3*100 yld3,
  case when coalesce(y23,-1)>0 and coalesce(y24,-1)>0 and coalesce(y25,-1)>0 then 1 else 0 end c3,
  case when tl/ta < 0.6 then 1 else 0 end c4,
  (coalesce(d23/eps23,0)+coalesce(d24/eps24,0)+coalesce(d25/eps25,0))/3*100 payout3,
  (coalesce(ocf23/d23,0)+coalesce(ocf24/d24,0)+coalesce(ocf25/d25,0))/3 cf_div3,
  (coalesce(roe23,0)+coalesce(roe24,0)+coalesce(roe25,0))/3 roe3,
  (coalesce(cf23/np23,0)+coalesce(cf24/np24,0)+coalesce(cf25/np25,0))/3*100 cf_np3,
  case when np22>0 and np25>0 then (power(np25/np22, 1.0/3)-1)*100 else null end cagr3,
  (dps_ttm/px)*100 yld_ttm
from a
"""

df = q(base)
print('universe:', len(df))

steps = []
cur = df
steps.append(('①三年均分红', cur[cur.c1 == 1]))
cur = steps[-1][1]
steps.append(('②三年均股息率>3.5%', cur[cur.yld3 > 3.5]))
cur = steps[-1][1]
steps.append(('③净利三年均增长', cur[(cur.c3 == 1)]))
cur = steps[-1][1]
steps.append(('④负债率<60%', cur[cur.c4 == 1]))
cur = steps[-1][1]
steps.append(('⑤支付率30-80%', cur[(cur.payout3 >= 30) & (cur.payout3 <= 80)]))
cur = steps[-1][1]
steps.append(('⑥现金流/分红>1', cur[cur.cf_div3 > 1]))
cur = steps[-1][1]
steps.append(('⑦ROE>8%', cur[cur.roe3 > 8]))
cur = steps[-1][1]
steps.append(('⑧现金流/净利>80%', cur[cur.cf_np3 > 80]))
cur = steps[-1][1]
steps.append(('⑨12月涨跌>-20%', cur[cur.ret12m > -20]))
cur = steps[-1][1]
steps.append(('⑩CAGR>3%', cur[cur.cagr3 > 3]))
cur = steps[-1][1]
steps.append(('⑪累计分红>10亿', cur[cur.amt_yi > 10]))
cur = steps[-1][1]

for name, d in steps:
    print(f'{name:22s} 剩 {len(d)}')

out = cur.sort_values('yld_ttm', ascending=False)
cols = ['symbol','name','yld_ttm','yld3','d23','d24','d25','c23','c24','c25','eps23','eps24','eps25',
        'payout3','roe3','cf_div3','cf_np3','cagr3','amt_yi','ret12m','px']
out[cols].to_csv('D:/repository/数据湖/分析产出/高股息筛选结果.csv', index=False, encoding='utf-8-sig')
print('result rows:', len(out))
print(out[['symbol','name','yld_ttm','yld3','payout3','roe3','amt_yi','ret12m']].head(30).to_string())
