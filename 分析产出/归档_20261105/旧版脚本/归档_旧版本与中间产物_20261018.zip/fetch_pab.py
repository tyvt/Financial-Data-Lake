# -*- coding: utf-8 -*-
import requests, pandas as pd, json
pd.set_option('display.width',300); pd.set_option('display.max_columns',30)

def fetch(code):
    url="https://datacenter.eastmoney.com/securities/api/data/v1/get"
    p={"reportName":"RPT_F10_FINANCE_MAINFINADATA",
       "columns":"SECUCODE,REPORT_DATE,REPORT_DATE_NAME,HXYJBCZL,NEWCAPITALADER,FIRST_ADEQUACY_RATIO,NONPERLOAN,BLDKBBL,LOAN_PROVISION_RATIO,NET_INTEREST_MARGIN,ROEJQ,PARENTNETPROFIT,PARENTNETPROFITTZ,TOTALOPERATEREVETZ",
       "filter":f'(SECUCODE="{code}")',"pageSize":30,"pageNumber":1,
       "sortColumns":"REPORT_DATE","sortTypes":-1,"source":"HSF10","client":"PC"}
    r=requests.get(url,params=p,headers={"User-Agent":"Mozilla/5.0"},timeout=20)
    j=r.json()
    if not j.get("result"): print(code,"FAIL",j); return None
    return pd.DataFrame(j["result"]["data"])

out=[]
for c in ["000001.SZ","002966.SZ"]:
    df=fetch(c)
    if df is not None:
        df['symbol']=c; out.append(df)
        print(f"--- {c} ---")
        print(df[['REPORT_DATE_NAME','HXYJBCZL','NEWCAPITALADER','FIRST_ADEQUACY_RATIO','NONPERLOAN','BLDKBBL','NET_INTEREST_MARGIN','ROEJQ']].head(10).to_string(index=False))
if out:
    pd.concat(out).to_csv('银行专项指标_深市补充.csv',index=False,encoding='utf-8-sig')
    print("\n已保存 银行专项指标_深市补充.csv")
