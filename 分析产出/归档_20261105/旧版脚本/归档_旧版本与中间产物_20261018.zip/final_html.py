# -*- coding: utf-8 -*-
import pandas as pd, numpy as np, duckdb
pd.set_option('display.width',320)
src=pd.read_csv('高股息筛选结果_行业豁免版.csv',encoding='utf-8-sig')
print(src[src.name.isin(['洪城环境','青岛港','沪农商行','唐山港','农业银行'])][['name','payout3','cfdiv3','roe3','debt','yld3']].to_string(index=False))

# 深市底线核验（复用前面的结果）
chk=pd.read_csv('深市子池_分红底线核验.csv',encoding='utf-8-sig')
print()
print(chk[chk['标的'].isin(['格力电器','云南白药','双汇发展','平安银行','苏州银行','苏泊尔'])].to_string(index=False))
