"""生成高股息筛选 HTML 报表（读取 screen_dividend.py 的口径）。"""
import duckdb, json, html

DB = 'D:/repository/数据湖/data/cnequity/duckdb/cnequity.duckdb'
con = duckdb.connect(DB, read_only=True)
q = lambda s: con.sql(s).df()

con.execute("""
create or replace temp view dps as
select symbol, year(ex_date) y, sum(cash_dividend) dps from corporate_actions
where action_type='cash_dividend' and cash_dividend is not null
  and ex_date between DATE '2023-01-01' and DATE '2025-12-31' group by 1,2
""")
con.execute("""
create or replace temp view yclose as
with lastd as (select year(trade_date) y, max(trade_date) d from daily_bars
               where trade_date between DATE '2023-01-01' and DATE '2025-12-31' group by 1)
select b.symbol, lastd.y, b.close from daily_bars b join lastd on b.trade_date=lastd.d
""")
con.execute("""
create or replace temp view fin as
select symbol, report_period,
  max(case when item_code='net_profit' then item_value end) np,
  max(case when item_code='net_profit_yoy' then item_value end) np_yoy,
  max(case when item_code='roe' then item_value end) roe,
  max(case when item_code='eps' then item_value end) eps,
  max(case when item_code='ocf_per_share' then item_value end) ocfps,
  max(case when item_code='total_assets' then item_value end) ta,
  max(case when item_code='total_liabilities' then item_value end) tl,
  max(case when item_code='net_cash_operate' then item_value end) ocf
from financial_statement_items
where report_period in ('2022Q4','2023Q4','2024Q4','2025Q4','2026Q2') group by 1,2
""")
con.execute("""
create or replace temp view ret12 as
with p as (select symbol,
  max(case when trade_date=DATE '2025-10-09' then qfq_close end) p0,
  max(case when trade_date=DATE '2026-10-09' then qfq_close end) p1
 from daily_bars_adj where trade_date in (DATE '2025-10-09', DATE '2026-10-09') group by 1)
select symbol, (p1/p0-1)*100 ret12m from p where p0>0 and p1 is not null
""")
con.execute("""
create or replace temp view latest as
with lastd as (select max(trade_date) d from daily_bars)
select b.symbol, b.close px from daily_bars b join lastd on b.trade_date=lastd.d
""")
con.execute("""
create or replace temp view dps_ttm as
select symbol, sum(cash_dividend) dps_ttm from corporate_actions
where action_type='cash_dividend' and ex_date > DATE '2025-10-09' and ex_date <= DATE '2026-10-09'
group by 1
""")
con.execute("""
create or replace temp view div_total as
with ca as (
  select c.symbol, c.cash_dividend * s.total_shares amt
  from corporate_actions c asof left join share_structure s
    on c.symbol = s.symbol and c.ex_date >= s.change_date
  where c.action_type='cash_dividend' and c.cash_dividend is not null
    and c.ex_date between DATE '2023-01-01' and DATE '2025-12-31')
select symbol, sum(amt)/1e8 amt_yi from ca group by 1
""")

rows = q("""
with b as (
  select i.symbol, i.name from instruments i
  where i.asset_type='stock' and i.list_date <= DATE '2022-01-01'
    and (i.delist_date is null or i.delist_date > DATE '2026-10-01')),
a as (
  select b.symbol, b.name, d23.dps d23, d24.dps d24, d25.dps d25,
    c23.close c23, c24.close c24, c25.close c25,
    f22.np np22, f23.np np23, f24.np np24, f25.np np25,
    f23.np_yoy y23, f24.np_yoy y24, f25.np_yoy y25,
    f23.roe roe23, f24.roe roe24, f25.roe roe25,
    f23.eps eps23, f24.eps eps24, f25.eps eps25,
    f23.ocf cf23, f24.ocf cf24, f25.ocf cf25,
    f26.ta, f26.tl, r.ret12m, l.px, t.dps_ttm, dt.amt_yi
  from b
  left join dps d23 on d23.symbol=b.symbol and d23.y=2023
  left join dps d24 on d24.symbol=b.symbol and d24.y=2024
  left join dps d25 on d25.symbol=b.symbol and d25.y=2025
  left join yclose c23 on c23.symbol=b.symbol and c23.y=2023
  left join yclose c24 on c24.symbol=b.symbol and c24.y=2024
  left join yclose c25 on c25.symbol=b.symbol and c25.y=2025
  left join fin f22 on f22.symbol=b.symbol and f22.report_period='2022Q4'
  left join fin f23 on f23.symbol=b.symbol and f23.report_period='2023Q4'
  left join fin f24 on f24.symbol=b.symbol and f24.report_period='2024Q4'
  left join fin f25 on f25.symbol=b.symbol and f25.report_period='2025Q4'
  left join fin f26 on f26.symbol=b.symbol and f26.report_period='2026Q2'
  left join ret12 r on r.symbol=b.symbol
  left join latest l on l.symbol=b.symbol
  left join dps_ttm t on t.symbol=b.symbol
  left join div_total dt on dt.symbol=b.symbol)
select a.*,
  (coalesce(d23/c23,0)+coalesce(d24/c24,0)+coalesce(d25/c25,0))/3*100 yld3,
  (coalesce(d23/eps23,0)+coalesce(d24/eps24,0)+coalesce(d25/eps25,0))/3*100 payout3,
  (coalesce(cf23/d23,0)+coalesce(cf24/d24,0)+coalesce(cf25/d25,0))/3 cf_div3,
  (coalesce(roe23,0)+coalesce(roe24,0)+coalesce(roe25,0))/3 roe3,
  (coalesce(cf23/np23,0)+coalesce(cf24/np24,0)+coalesce(cf25/np25,0))/3*100 cf_np3,
  case when np22>0 and np25>0 then (power(np25/np22,1.0/3)-1)*100 end cagr3,
  dps_ttm/px*100 yld_ttm
from a
where d23>0 and d24>0 and d25>0
""")

# 逐年明细
def yearly(r):
    out = {}
    for k, yr in (('roe', ['roe23','roe24','roe25']), ('payout', ['p_23','p_24','p_25']),
                  ('cfdiv', None), ('cfnp', None)):
        pass
    return {}

df = rows.copy()
for y in ('23','24','25'):
    df['p_'+y] = df['d'+y] / df['eps'+y] * 100
    df['cd_'+y] = df['cf'+y] / df['d'+y]
    df['cn_'+y] = df['cf'+y] / df['np'+y] * 100

df = df[(df.yld3 > 3.5) & (df.y23 > 0) & (df.y24 > 0) & (df.y25 > 0) &
        (df.tl / df.ta < 0.6) & (df.payout3.between(30, 80)) & (df.cf_div3 > 1) &
        (df.roe3 > 8) & (df.cf_np3 > 80) & (df.ret12m > -20) & (df.cagr3 > 3) & (df.amt_yi > 10)]
df = df.sort_values('yld_ttm', ascending=False)

hdr = ['代码', '名称', '当前股息率<br><span class="sub">TTM</span>', '3年均股息率',
       'ROE<br><span class="sub">加权 %</span>', '股息支付率<br><span class="sub">%</span>',
       '现金流/分红<br><span class="sub">倍</span>', '现金流/净利<br><span class="sub">%</span>',
       '归母净利CAGR<br><span class="sub">2022→2025</span>', '累计分红<br><span class="sub">亿元</span>',
       '近12月涨跌']

def cell_avg(v, ys, fmt, suffix=''):
    small = ' / '.join(fmt.format(x) if x == x and x is not None else '—' for x in ys)
    return f'<div class="avg">{fmt.format(v)}</div><div class="yr">{small}</div>'

body = []
for _, r in df.iterrows():
    ys = [r.roe23, r.roe24, r.roe25]
    ps = [r.p_23, r.p_24, r.p_25]
    cs = [r.cd_23, r.cd_24, r.cd_25]
    ns = [r.cn_23, r.cn_24, r.cn_25]
    up = r.ret12m >= 0
    body.append(f"""<tr>
<td class="code">{r.symbol}</td><td class="name">{html.escape(str(r['name']))}</td>
<td class="num hi">{r.yld_ttm:.2f}%</td><td class="num">{r.yld3:.2f}%</td>
<td class="num">{cell_avg(r.roe3, ys, '{:.2f}')}</td>
<td class="num">{cell_avg(r.payout3, ps, '{:.1f}')}</td>
<td class="num">{cell_avg(r.cf_div3, cs, '{:.2f}')}</td>
<td class="num">{cell_avg(r.cf_np3, ns, '{:.0f}')}</td>
<td class="num">{r.cagr3:+.1f}%</td><td class="num">{r.amt_yi:.1f}</td>
<td class="num {'up' if up else 'down'}">{r.ret12m:+.1f}%</td></tr>""")

funnel = [('初始股票池（2022 年前上市、未退市）', 4492), ('① 2023–2025 连续现金分红', 2539),
          ('② 3 年均股息率 > 3.5%', 365), ('③ 归母净利 3 年均正增长', 64),
          ('④ 资产负债率 < 60%', 30), ('⑤ 3 年均支付率 30–80%', 22),
          ('⑥ 现金流/分红 > 1', 21), ('⑦ 3 年均 ROE > 8%', 18),
          ('⑧ 现金流/净利 > 80%', 16), ('⑨ 近 12 月涨跌 > −20%', 13),
          ('⑩ 净利 CAGR > 3%', 13), ('⑪ 累计分红 > 10 亿元', 9)]
fhtml = ''.join(f'<li><span>{n}</span><b>{c}</b></li>' for n, c in funnel)

doc = f"""<!DOCTYPE html><html lang="zh-CN"><head><meta charset="utf-8">
<title>高股息 11 条件筛选结果</title>
<style>
*{{box-sizing:border-box}}
body{{margin:0;padding:32px 28px 48px;background:#0d1117;color:#e6edf3;
 font-family:-apple-system,"Segoe UI","Microsoft YaHei",sans-serif}}
h1{{font-size:22px;margin:0 0 6px;font-weight:600;letter-spacing:.3px}}
.meta{{color:#8b949e;font-size:12.5px;line-height:1.7;margin-bottom:22px}}
.meta b{{color:#c9d1d9;font-weight:600}}
.funnel{{display:flex;flex-wrap:wrap;gap:6px;list-style:none;padding:0;margin:0 0 30px}}
.funnel li{{background:#161b22;border:1px solid #21262d;border-radius:6px;padding:7px 11px;
 font-size:11.5px;color:#8b949e;display:flex;gap:8px;align-items:center}}
.funnel li b{{color:#58a6ff;font-size:14px;font-weight:600;font-variant-numeric:tabular-nums}}
table{{width:100%;border-collapse:collapse;font-size:13px;font-variant-numeric:tabular-nums}}
thead th{{text-align:right;padding:9px 10px;border-bottom:1px solid #30363d;color:#8b949e;
 font-size:11.5px;font-weight:500;line-height:1.5;white-space:nowrap;vertical-align:bottom}}
thead th:first-child,thead th:nth-child(2){{text-align:left}}
.sub{{color:#484f58;font-size:10px}}
tbody td{{padding:11px 10px;border-bottom:1px solid #161b22;text-align:right;white-space:nowrap}}
tbody td.code{{text-align:left;color:#8b949e;font-size:12px}}
tbody td.name{{text-align:left;font-weight:600}}
tbody tr:hover{{background:#11161d}}
.num{{}}
.avg{{font-weight:700;font-size:13.5px}}
.yr{{color:#6e7681;font-size:10.5px;margin-top:2px;letter-spacing:.2px}}
.hi{{color:#f0883e;font-weight:700;font-size:14.5px}}
.up{{color:#f85149;font-weight:600}}
.down{{color:#3fb950;font-weight:600}}
.note{{margin-top:26px;font-size:11.5px;color:#6e7681;line-height:1.9;max-width:1100px}}
.note b{{color:#8b949e}}
</style></head><body>
<h1>高股息 11 条件筛选结果</h1>
<div class="meta">数据源 <b>cnequity 数据湖</b>（4961 只 A 股 / 财务 2022Q1–2026Q2 全覆盖）　·　
价格区间 <b>2025-10-09 → 2026-10-09</b>（前复权）　·　报告期基准 <b>2026 中报</b>　·　
按<b>当前股息率（TTM）</b>降序　·　命中 <b>{len(df)}</b> 只</div>
<ul class="funnel">{fhtml}</ul>
<table><thead><tr>{''.join(f'<th>{h}</th>' for h in hdr)}</tr></thead>
<tbody>{''.join(body)}</tbody></table>
<div class="note">
<b>口径</b>：每股现金分红取 <code>corporate_actions.cash_dividend</code>（税前），按<b>除权日所在自然年</b>归集并累加年内中期+年度分红；
年末收盘价取各年最后一个交易日。ROE 为加权净资产收益率（年报口径），EPS 为基本每股收益，
经营现金流为每股经营现金流。<br>
<b>已知偏差</b>：① 除权日与会计年度存在一年错位（如 2025 年度分红多在 2026 年 7 月除权），
三年均值受影响有限但不为零；② 累计分红 = 每股派现 × 除权日前最近一期总股本，为估算值。
</div></body></html>"""

open('D:/repository/数据湖/分析产出/高股息筛选结果.html', 'w', encoding='utf-8').write(doc)
print('rows', len(df))
