# -*- coding: utf-8 -*-
"""深市低波高股息候选扫描：从 283 只(①②⑨通过) 中找深市可配底仓"""
import duckdb, pandas as pd, numpy as np
pd.set_option('display.width',330); pd.set_option('display.max_columns',60)
BASE='2026-10-15'; ANN=np.sqrt(252)
con=duckdb.connect(':memory:')
con.execute("ATTACH 'D:/repository/数据湖/data/cnequity/duckdb/cnequity.duckdb' AS src (read_only)")

cand=pd.read_csv('候选_①②⑨通过_283只.csv',encoding='utf-8-sig')
cand['板块']=np.where(cand.symbol.str.startswith('6'),'沪市','深市')
sz=cand[cand.板块=='深市'].copy()
print(f"深市候选 {len(sz)} 只")

q=",".join("'"+s+"'" for s in sz.symbol)
px=con.execute(f"select symbol,trade_date,close from src.daily_bars where symbol in ({q}) and trade_date<=DATE '{BASE}' and close>0 order by 1,2").df()
ca=con.execute(f"""select symbol,cast(ex_date as date) ex_date,coalesce(cash_dividend,0) cash,
 coalesce(bonus_ratio,0) bonus,coalesce(transfer_ratio,0) transfer from src.corporate_actions
 where symbol in ({q}) and cast(ex_date as date)<=DATE '{BASE}'""").df()
rec=[]
for s,g in px.groupby('symbol'):
    g=g.sort_values('trade_date').reset_index(drop=True)
    g['c_prev']=g['close'].shift(1)
    c=ca[ca.symbol==s]
    g=g.merge(c[['ex_date','cash','bonus','transfer']],left_on='trade_date',right_on='ex_date',how='left')
    prev=(g['c_prev']-g['cash'].fillna(0))/(1+g['bonus'].fillna(0)+g['transfer'].fillna(0))
    g['r']=np.where(g['ex_date'].notna(),g['close']/prev-1,g['close']/g['c_prev']-1)
    rec.append(g[['symbol','trade_date','close','r']])
allr=pd.concat(rec,ignore_index=True)
vr=[]
for s,g in allr.groupby('symbol'):
    r=g['r'].dropna().tail(252)
    if len(r)<200: continue
    P=(1+r).cumprod()
    vr.append({'symbol':s,'vol':round(float(np.std(r,ddof=1))*ANN*100,2),
               'mdd':round(float((P/P.cummax()-1).min())*100,2)})
vol=pd.DataFrame(vr)
amt=con.execute(f"""with d as (select symbol,amount,row_number() over(partition by symbol order by trade_date desc) rk
 from src.daily_bars where symbol in ({q}) and trade_date<=DATE '{BASE}' and amount is not null)
 select symbol,avg(amount)/1e4 amt_wan from d where rk<=63 group by 1""").df()
pxl=con.execute(f"""select symbol, arg_max(close,trade_date) px from src.daily_bars where symbol in ({q}) group by 1""").df()

m=sz.merge(vol,on='symbol').merge(amt,on='symbol').merge(pxl,on='symbol')
m=m.rename(columns={'三年均股息率':'yld3'})
m['yld_now']=(m.d25/m.px*100).round(2)

f=m[(m.vol<25)&(m.amt_wan>=5000)&(m.yld_now>=3.5)].sort_values('vol')
print(f"\n=== 深市：波动<25% & 成交额≥5000万 & 当前股息率≥3.5% ===")
print(f"符合 {len(f)} 只")
if len(f):
    print(f[['symbol','name','vol','mdd','amt_wan','yld_now','yld3','d25']].round(2).to_string(index=False))

f2=m[(m.vol<30)&(m.amt_wan>=5000)&(m.yld_now>=3.5)].sort_values('vol')
print(f"\n=== 放宽到 <30%：符合 {len(f2)} 只 ===")
print(f2[['symbol','name','vol','mdd','amt_wan','yld_now']].round(2).to_string(index=False))
f.to_csv('深市低波候选.csv',index=False,encoding='utf-8-sig')
